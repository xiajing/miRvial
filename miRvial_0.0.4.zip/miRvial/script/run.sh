genome_bowtie_build=$1
genome_fastq=$2
program_param=$3
known_miRNA_gff=$4
genome_fastq_lib=$5
./mirvial.sh  $genome_bowtie_build $genome_fastq $program_param $known_miRNA_gff $genome_fastq_lib

################ merge duplicate loci in simple ##############
cat simple  | grep -P ">|\.*[AGCTUagctu]+\.*\s[0-9]+" |  awk '{if($1~/>/){str=$1;}else{str=$1; gsub(/\./, "", str);} print str}' | sed 'N;N;s/\n/\t/g;P;D' | awk '{if($2$3==na){ }else{ print; na=$2$3; } }' | cut -f1 >map
awk '{if(FNR==NR){if($1~/>/){ if(na!=""){ map[na]=str;}  na=$1; str=$1;}else{str=str"\n"$0;}  }else{ map[na]=str; print map[$1]; }}'  simple map >simple.merge



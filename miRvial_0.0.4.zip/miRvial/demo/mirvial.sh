#!/bin/bash

# CHANGE TO THE directory  of java class files
echo "running"
java_r=$(which java)
#java_r="/cluster/cloud/java8/bin/java"

rna_fold="../bin/RNAfold_macos"
bowtie_j="../bin/bowtie_macos"
bowtie_build_j="../bin/bowtie-build_macos"

##### IF *UNIX, USE this ##
#rna_fold="../bin/RNAfold"
#bowtie_j="../bin/bowtie"
#bowtie_build_j="../bin/bowtie-build"


## param.txt should be in the same dir
## $1 human hg19 bowtie-built index
## $2 unique sequenceing reads
## $3 parameter file
##
if [[ -n "$1" && -n "$2" && -n "$3" ]]; then
echo "We're good"
else
echo "args should be correct"
exit
fi

### EDITING
$java_r -cp ../src/ PreProcess $2 $3 PROCESS_READS
#../script/trimreads.sh $2 $3 >tmp.fa

## mapping
# -m int  important, the reads that will be considered
$bowtie_j $1 -n 0 -k 5 -m 10 --suppress 8 -f tmp.fa >map.tmp
sort -T ./ -k3,3 -k4,4n map.tmp >map.sort

# remove  known miRNA loci
if [[ -n "$4" ]]; then
$java_r -cp ../src/ RemoveLoci $4 map.sort map true
else
echo "error"
#mv map.sort map
fi

##
## extract sequences
$java_r -cp ../src/ PreProcess map $3 PROCESS_MAP 
sort -T ./ -k3,3 -k4,4n tmp_p >tmp_pp
sort -T ./ -k3,3 -k4,4n tmp_m >tmp_mm




$java_r -cp ../src/ -Xmx2G ScanMapExRegion tmp_p tmp_m slide.fa $3
#awk '{if( $0 ~/>/){ tot++; print $0"_"tot;}else{print $0;} }' slide.fa >slide_1
#mv slide_1 slide.fa

## Folding
echo 'folding'
$rna_fold --noPS <slide.fa >slide.str

## filter structure with higher energy
$java_r  -cp ../src/ FilterStr slide.str pre100.fa pre100.str $3



## map reads to extracted sequences; Draw alignment of reads
$bowtie_build_j pre100.fa pre100 >tmpout
$bowtie_j pre100  -n 0 -a --suppress 8 -f $2  >topre.map --al topre.fa

echo 'RevCom'
$java_r  -cp ../src/ RevComNegRead topre.map topre_as.map

echo 'sorting and merge'
sort -T ./ -k5,5 topre_as.map >tmp1
#mv tmp1 topre_as.map
if [[ -n "$5" ]]; then
$java_r  -cp ../src/  Merge tmp1 $5 topre_as.map
else
mv tmp1 topre_as.map
fi

echo 'ready to draw'
$java_r -cp ../src/ PreProcess topre_as.map $3 PROCESS_MAP_ADV
sort -T ./ -k8,8n tmp_p >topre_as.map_p
sort -T ./ -k8,8n tmp_m >topre_as.map_m

# draw alignment
$java_r  -cp ../src/ DrawAlignment pre100.str topre_as.map_p topre_as.map_m tmp_align.txt

# Post filter
$java_r  -cp ../src/ miRvial tmp_align.txt align.txt cand.txt simple.txt $3


rm tmp*
rm topre*
rm pre100*
rm map*

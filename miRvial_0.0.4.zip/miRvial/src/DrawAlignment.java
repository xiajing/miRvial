/**
    miRvial - miRNAs via integrative analysis
    Copyright (C) 2015

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 **/

import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.LinkedList;



public class DrawAlignment {
	
	public static String newline = System.getProperty("line.separator");

	public static String s1 = null;
	public static String s2 = null;
	
	public static void readinStrc(String fn, String pname, String mname, String  out) {
		try {
			BufferedReader chroReader = new BufferedReader(new FileReader(fn));
			BufferedReader preader = new BufferedReader(new FileReader(pname));
			BufferedReader mreader = new BufferedReader(new FileReader(mname));
			PrintWriter w = new PrintWriter(out);
			
			String s = chroReader.readLine();
			s1 = preader.readLine();
			s2 = mreader.readLine();
			
			while (s != null) {		
				if(s.contains(">")){
					Alignment al = new Alignment();
					al = AlignmentFunction.getBlock(al, s, chroReader);
					String tmp;
					if(al.name.contains(">")){
						tmp =al.name.replace(">", "");
					}else{
						tmp =al.name;
					}
					
					HashMap<Integer, LinkedList<String>> wig = fetchWig("+", preader, tmp);
					drawAlignment("+", wig, w, al);
					
					wig = fetchWig("-", mreader, tmp);
					drawAlignment("-", wig, w, al);
		//			map.put(tmp.hashCode(), al);					
					s= al.cursor;
					
				}else{
					s = chroReader.readLine();
				}		
			}
			w.flush(); w.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	public static HashMap<Integer, LinkedList<String>> fetchWig(String fw, BufferedReader reader, String curr) {
		HashMap<Integer, LinkedList<String>> wig = new HashMap<Integer, LinkedList<String>>();

		try {
			String ts[] = null;
			String s = null;
			if(fw.equals("+")) { s = s1;}else{
				s = s2;
			}
			
			while (s != null) {		
				ts = s.split("\\s+");
				if(ts[2].equals(curr)){
					wig = addpos(s, wig);
					s = reader.readLine();	
					if(fw.equals("+")) { s1= s;}else{
						s2=s;
					}
				}else{
					return wig;
				
				}							
			}		
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return wig;
	}

	private static HashMap<Integer, LinkedList<String>> addpos(String s, HashMap<Integer, LinkedList<String>> wig) {
		// TODO Auto-generated method stub
		String t[] = s.split("\t");
		int st = Integer.valueOf(t[3]);
//		int st = Integer.valueOf(t[3]) + t[4].length();		
		if(wig.containsKey(st)){
			LinkedList<String> tmp = wig.get(st);			
			tmp.add(s);
			wig.put(st, tmp);
			
		}else{
			LinkedList<String> lines = new LinkedList<String>();
			lines.add(s);
			wig.put(st, lines);
		}
		
		return wig;
	}
	
	private static void drawAlignment(String fw, HashMap<Integer, LinkedList<String>> wig, PrintWriter w, Alignment al) {
		// TODO Auto-generated method stub
		if(fw.equals("+")){
			w.println(al.name);
			w.println(al.seq);
			for(int i =0 ; i < al.strc.size(); i++) w.println((String)al.strc.get(i));
		}else{
			w.println("negative");
		}
		
		int len = al.seq.split("\\s+")[0].length();	
		for(int i = 0; i < len; i++){
			if(wig.containsKey(i)){
				LinkedList<String> l = wig.get(i);
				drawlines(fw, l, w, len);
			}
		}		
	}
	
	private static void drawlines(String fw ,LinkedList<String> l, PrintWriter w, int len) {
		// TODO Auto-generated method stub
		for(int j = 0; j < l.size(); j++){
			String str = (String)l.get(j);
			String sps[] = str.split("\t");
			
			int num;
			if(sps[0].contains("_x")){
				num = Integer.valueOf(sps[0].split("_x")[1]);
			}else{
				if(sps[0].contains("_")){
					num = Integer.valueOf(sps[0].split("_")[1]);
				}else{
					num = Integer.valueOf(sps[0] );
				}
			}
			 
			char dots[] = new char[len];
			for(int i = 0; i < len; i++){
				dots[i] ='.';
			}	
			char arr[] = sps[4].toCharArray();
			if(fw.equals("+")) {arr = sps[4].toCharArray();}else{
				arr = new StringBuffer(sps[4]).reverse().toString().toCharArray();
			}		
	
			int st = Integer.valueOf(sps[3]); 
			int ed = st + sps[4].length()-1;
			
			for(int i = st,n =0; i <= ed; i++,n++){
				dots[i] = arr[n] ;
			}
			w.println(String.valueOf(dots)+"\t"+num+"\t"+sps[4].length()+"\t"+sps[6]);
		}	
	}

	
	public static void main(String args[]) throws IOException{
		//readinStrc("pre100.str", "topre.map+", "topre.map-", "topre.map.align");
		readinStrc(args[0], args[1],args[2],args[3]);
	
	}
} 


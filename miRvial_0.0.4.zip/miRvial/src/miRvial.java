/**
*    miRvial - miRNAs via integrative analysis
*    Copyright (C) 2015
*
*    This program is free software: you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation, either version 3 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 **/

/**
* Contact: Jing Xia <jxia@wustl.edu>
**/


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Properties;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 * post filter has negative reads or reads are dispersed not concentrated
 * @author think
 *
 */
public class miRvial {

	private static int mincopy = 5;	// minimum threshold for the peak read in a cluster
	
	// parameters related to folding structure 
	// used in minimum criteria  
	private static int minlen = 11;	 // 
	private static int unpair = 8;   // # unpaired bases allowed
	private static int minloci = 30;

	// peak read must overlap with stem region at least overlap_len
	private static int overlap_len = 10;

	// used in duplex structure
	private static int overhang_min = 0;
	private static int overhang_max = 4;
	
	// used in finding duplex 
	private static int read_min = 20;	// length of a read
	private static int read_max = 25;
	
	// used in readstrcutre 
	// the number of consecutive base pairings along a stem
	private static int base_pair_num = 17;	// min number of based pairs
	private static int hairpin_len = 45;	// min length of a hairpin

	private static int buldge_gap = 8;
	
	PrintWriter w_sim = null;
	PrintWriter w = null;
	PrintWriter w_cand = null;
	BufferedReader chroReader = null;
	
	private static boolean useheuristic = false;
	Process p;	//used for call "RNAfold"
	
	
	private static Logger theLogger =
		      Logger.getLogger(miRvial.class.getName());
	
	
	public miRvial(String i_file, String out, String cand, String simple){
		try {
			w = new PrintWriter(out);
			w_cand = new PrintWriter(cand);
			w_sim = new PrintWriter(simple);
			chroReader = new BufferedReader(new FileReader(i_file));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	} 
	
	
	// i_file is the input file
	// out: output file with miRNAs which satisfy rule (A) and rule (B)  
	// cand: candidate miRNAs which satisfy rule (B) only
	// simple: a simplified version of out
	
	public void filter() {
		try {
			
			String s = chroReader.readLine();
			while (s != null) {
				
				if(s.contains(">")){
					Alignment al = new Alignment();
					al = AlignmentFunction.getBlock(al, s, chroReader); 
					
//					test(al);
					
					if(isHairpin(al)){  //the presence of a hairpin
						theLogger.info("presence of hairpin ");
						
						if(hasDuplex( al,0,3) ){  // the presence of a duplex with a few overhangs					
							
							AlignmentFunction.write(w, al); 
							
						}else{
						//	theLogger.info("no hairpin found");
							
							if(useheuristic && heuristicsearch(al) ){	// application of the heuristic method
									
								AlignmentFunction.write(w, al); 
							}else{
								AlignmentFunction.write(w_cand, al);
								//if(readsStructure_1(al)){FilterStr.write(w_cand, al);} // lower criteria  
							}					
						}
					}
						
					s = al.cursor;
				}else{
					s = chroReader.readLine();

				}
			}
			System.out.println("done");
			w.flush(); w.close();
			w_cand.flush(); w_cand.close();
			w_sim.flush(); w_sim.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	
	private boolean hasDuplex(Alignment al, int min, int max) {
		if (al.preads.size() == 0) return false;
		int id = al.pread_maxid; 
				
		int a = getStart((String)al.preads.get(id));  // max_read 5p
		int b = getEnd((String)al.preads.get(id));	// max_read 3p
		int str_len = b - a +1;
		
		for(int num1=0; num1<al.strc.size(); num1++){
			String strc =((String)al.strc.get(num1));
			int pair[] = getPair(strc); 

			int x = indexstart(al, strc, id); 	// get max read 5p end
			// get a list of reads whose 3p end are covering 5p end of max_read
			LinkedList<int[]> op = checkoverhang(al, b , pair[x+1]-1 + (x-a), min, max); 

			// if any read's 5p end is  located  within max_read 3p 
			Iterator<int[]> it = op.iterator();
		    while (it.hasNext()) {
		    	int[] rd_i = (int [])it.next();
		    	x = indexstart(al, strc, rd_i[0]);	// get 5p end of a read 
		    	int len = b - ((pair[x+1]-1) + (x-rd_i[1]));	// max_read's 3p minus a read's 5p 

		    	theLogger.info(len+"\t"+str_len+"\t");
		    	
			// overhand is 0 to 3 and max_read length is 20-25
		    	if(len >=min && len<=max && 
		    			str_len>=read_min && str_len <=read_max && readsStructure_1(al) ){
		    	
		    		w_sim.println(al.name);
		    		w_sim.println(al.seq);
		    		w_sim.println(strc);
		    		w_sim.println((String)al.preads.get(id));
		    		w_sim.println((String)al.preads.get(rd_i[0])+"\t"+String.valueOf(len)+"\t"
		    				+String.valueOf(rd_i[1])+"\t"+String.valueOf(x)+"\t"+String.valueOf(pair[x+1]));
			    	
		    		if(theLogger.isLoggable(Level.ALL)){
		    			for(int n=0; n<pair.length;n++){theLogger.info((n+1)+"\t"+pair[n]);}
		    		}
		    		
		    		return true; 
		    	}		    }
		}
		
		return false;
	}
	

	private LinkedList<int[]> checkoverhang(Alignment al, int in_end, int j, int min, int max) {
		// TODO Auto-generated method stub
		LinkedList<int[]> ret = new LinkedList<int[]>(); 
		
		for(int i = 0; i<al.preads.size(); i++){
			int end = getEnd((String)al.preads.get(i));
			int start= getStart((String)al.preads.get(i));
			int len = Math.abs(end-start)+1;

			if(len>=read_min && len <=read_max && Math.abs(end-in_end) >=20 && end - j >=min && end -j <=max){
				int[] st = new int[2];
				st[0] = i;
				st[1] = getStart((String)al.preads.get(i));
				ret.add(st);
			}
		}
		return ret;
	}


	private boolean heuristicsearch(Alignment al) {
		// TODO Auto-generated method stub
		if (al.preads.size() == 0) return false;
		int id = al.pread_maxid; 
		int a_id = (Integer) al.preads_coords.get(id*2);
		int b_id = (Integer) al.preads_coords.get(id*2+1) + 1;

			
		for(int num1=0; num1<al.preads.size(); num1++){
				int a = (Integer) al.preads_coords.get(num1*2);
				int b = (Integer) al.preads_coords.get(num1*2+1) + 1;
		
/*			// it fails when miR* reads are outside the initial foling region	
 * 			if(Math.min(b, corrds[1])-Math.max(a, corrds[0]) <= overlap && 
						Math.min(b, corrds[3])-Math.max(a, corrds[2]) <= overlap ){continue;}*/
			//	System.err.println(al.name+"\t"+range[1]+"\t"+range[0]+"\t"+(Math.min(b, range[0])-Math.max(a, range[1])) );
				
				String chimericstr = new String(); String aligns[] = new String[2];
				
				String tmp[] = new String[2]; 
				tmp[0] = al.seq.substring(a,b);
				tmp[1] = al.seq.substring(a_id,b_id); 
				
				
				char[] dots = new char[tmp[1].length()+4]; char[] dots1 = new char[tmp[0].length()+4];
				Arrays.fill(dots, '.'); Arrays.fill(dots1, '.');
				
				if(num1 != id && (Math.min(b, b_id) - Math.max(a, a_id)) <= 0 ){
					if(a_id > a){ 
						chimericstr=tmp[0]+"NNNN"+tmp[1];					
						aligns[1] = tmp[0]+String.valueOf(dots)
							+((String)al.preads.get(num1)).replaceAll("\\.*[AGCTUagctu]+\\.*", "");
						aligns[0] = String.valueOf(dots1) + tmp[1] 
							+ ((String)al.preads.get(id)).replaceAll("\\.*[AGCTUagctu]+\\.*", "");  
					}else{ 
						chimericstr=tmp[1]+"NNNN"+tmp[0];  
						aligns[0] = tmp[1]+String.valueOf(dots1)
							+((String)al.preads.get(id)).replaceAll("\\.*[AGCTUagctu]+\\.*", "");
						aligns[1] = String.valueOf(dots) + tmp[0]+ "\t" 
							+ ((String)al.preads.get(num1)).replaceAll("\\.*[AGCTUagctu]+\\.*", "");  
					}
	          		
					Alignment chimeric_al = new Alignment(al.name, chimericstr, aligns);

					Alignment tmpal = callRNAfold(chimeric_al);
					if(hasDuplex(tmpal, overhang_min, overhang_max)){return true;}
				}
		}	
		return false;
	}



	private Alignment callRNAfold(Alignment chimeric_al) {
		// TODO Auto-generated method stub
		try {
			String cmd[] = new String [2];
			cmd[0]="RNAfold"; cmd[1]="-noPS";

			p = Runtime.getRuntime().exec(cmd);
			
			OutputStream aha = p.getOutputStream ();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(aha));
			writer.write(chimeric_al.name+"\n");			
			writer.write(chimeric_al.seq+"\n");
			writer.flush();

			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			
            	String strc = reader.readLine(); 
           		chimeric_al.strc.add(strc);
            
           	reader.close();
			writer.close();
			p.waitFor();
			p.destroy();

/*			System.out.println(fa_id);	System.out.println(seq); System.out.println(strc);		
			System.out.println((String)chimeric_al.preads.get(0)); 			
			System.out.println((String)chimeric_al.preads.get(1));*/

            	return chimeric_al;
            
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}


	// 0-based
	private int indexstart(Alignment al, String strc, int id) {
		// TODO Auto-generated method stub
		int j = -1;
	
		int a = getStart((String)al.preads.get(id)); 
		int b = getEnd((String)al.preads.get(id));
		String subStrc = strc.substring(a, b+1);
		
		if(subStrc.replaceAll("[^(]", "").length() > subStrc.replaceAll("[^)]", "").length() ){
			j = a+subStrc.indexOf("(");
		}else{
			j = a+subStrc.indexOf(")");
		}
		return j;
	}
	
	// lowest criteria: counting the number of base pairings of the peak read   
	private boolean readsStructure_1(Alignment al) {
		// TODO Auto-generated method stubString subStrc
		int id = al.pread_maxid; 
		int a = (Integer) al.preads_coords.get(id*2);
		int b = (Integer) al.preads_coords.get(id*2+1) + 1;
		
		for(int num1=0; num1<al.strc.size(); num1++){
			String strc =((String)al.strc.get(num1));
			String subStrc = strc.substring(a, b+1);
			String tmpstr= trimDot(subStrc); 

		//	System.out.println(subStrc+"\t"+tmpstr+"\t");

			if(tmpstr.replaceAll("[^.]", "").length() <= unpair &&
					(subStrc.replaceAll("[^(]", "").length() >=minlen ||
							subStrc.replaceAll("[^)]", "").length() >=minlen)){
				return true;			
			}
		
		}
	
		return false;
	}
	
	// check the presence of a hairpin-like structure based on both  
	// secondary structure and read alignment
	//  
	private boolean isHairpin(Alignment al) {
		// TODO Auto-generated method stub
		
		if (al.preads.size() == 0) return false;
		int id = al.pread_maxid;		
		int a_id = (Integer) al.preads_coords.get(id*2);
		int b_id = (Integer) al.preads_coords.get(id*2+1) + 1;
		
		String str[] = ((String)al.preads.get(id)).split("\\s+");		
		if( Integer.valueOf(str[1]) <mincopy || Integer.valueOf(str[3])>minloci ) return false;
		
		
		//System.out.println(al.strc.size());	
		for(int num1=0; num1<al.strc.size(); num1++){
			
			
			String strc =((String)al.strc.get(num1));
			strc = strc.split("\\s+")[0];
			int pair[] = getPair(strc); 
			
			LinkedList<int[]> stemList = AlignmentFunction.getStems(0, strc.length()-1, pair, buldge_gap);
		//	int len_opparm[] = getLenopparm_1(0, strc.length()-1, pair); 
			
			
			for(int idx= 0; idx<stemList.size();idx++){
				int len_opparm[] = (int [])stemList.get(idx);
				
				int corrds[] = new int[4];  
				corrds[0] = len_opparm[0]; corrds[1] = len_opparm[1];  
				corrds[2] = pair[len_opparm[0]];  corrds[3] = pair[len_opparm[1]];
				
				Arrays.sort(corrds);
				
				// overall hairpin length
				int hp_len = Math.abs(corrds[0]-corrds[3]);
				
				// justify whether the peak read overlap with the range of longest consecutive base parings    
				if(Math.min(b_id, corrds[1])-Math.max(a_id, corrds[0]) <= overlap_len && 
						Math.min(b_id, corrds[3])-Math.max(a_id, corrds[2]) <= overlap_len ){
					// do nothing
				}else{
					
					//System.out.println(al.name+"\t"+len_opparm[2]);				
					// justify whether the length of longest consecutive base parings and overall hairpin length
					if(len_opparm[2]>=base_pair_num && hp_len >=hairpin_len){return true;} //*************
				}				
			}
	
		}
		return false;
	}
	
	// get the longest consecutive base parings in a secondary structure 
/*	private int[] getLenopparm_1(int a, int b, int[] pair_t) {
		// TODO Auto-generated method stub
		int prev = 0; int max = 0; int cont_len=0;
		int coor[] = new int[2];
		int ret[] = new int[3]; 
		
		int num_p = 0;
		int num_unpaired = 0;
		
		int pair[] = new int[pair_t.length];
		for(int i = 0; i<pair.length;i++){pair[i] = pair_t[i];}
		
		cont_len=1; 
		for(int i=a; i<=b;i++){
			if(pair[i+1]==0){continue; }
			else{	
				coor[0] = pair[i+1];  coor[1] = pair[i+1]; prev = pair[i+1]; 
				break;
			}	
		}
		
		for(int i=a; i<=b;i++){
			if(pair[i+1]==0){
				num_unpaired++;
				continue; 
			}
			else{				
					// setting ****************
					int tmp = Math.abs(prev-pair[i+1]); 
					if( tmp  <= buldge_gap+1 && num_unpaired <= buldge_gap ){ cont_len+=tmp;  coor[1] = pair[i+1]; num_p++;} //*************
					else{
						if(num_p>max){max=num_p; ret[0]= coor[0]; ret[1]=coor[1]; ret[2]=num_p;}
						cont_len = 1; coor[0] = pair[i+1];  coor[1] = pair[i+1]; num_p=1;
					}
				
				prev = pair[i+1]; pair[pair[i+1]]=0;  num_unpaired=0;
			} 
		}
		
		if(num_p>max){max=cont_len; ret[0]= coor[0]; ret[1]=coor[1]; ret[2]=num_p;}
		return ret;
	} */
	
	//1-based
	private int[] getPair(String strcure) {
		// TODO Auto-generated method stub	
		//int len = strcure.length()+1;
		 Stack<Integer> st = new Stack<Integer>();
		
		char strc[] = strcure.split("\\s+")[0].toCharArray();
		int pair[] = new int[strc.length+1];
		
		for(int i = 0 ; i < strc.length; i++){
			switch(strc[i]){
			case '.': {continue;}
			case '(': {st.push(i+1); continue;}
			case ')': {int l = (Integer)st.pop();
			 			pair[i+1] = l; pair[l] = i+1;
					continue;}
			}
		}
		return pair;
	}
	
	private String trimDot(String subStrc) {
		// TODO Auto-generated method stub
		subStrc = subStrc.replaceAll("^\\.+", "");
		subStrc = subStrc.replaceAll("\\.+$", "");
		return subStrc;
	}
	// 0-based
	private int getStart(String string) {
		// TODO Auto-generated method stub
		String str[] = string.split("\\s+");	
		String read = str[0];
		int a = read.split("[agctuAGCTU]+")[0].length();
		return a;
	}
	// 0-based
	private int getEnd(String string) {
		// TODO Auto-generated method stub
		String str[] = string.split("\\s+");	
		String read = str[0];
		int a = read.split("[agctuAGCTU]+")[0].length();
		int b = a + read.replace(".", "").length() - 1;
		return b;
	}
	
	private static void init(Properties properties) {
		// TODO Auto-generated method stub
	
		// min copy number, when extract precursor, only consider reads having # >mincopy
		if(properties.getProperty("mincopy") != null){
			mincopy = Integer.valueOf(properties.getProperty("mincopy").trim());
		}else{
			mincopy = 5; 
		}
		
		if(properties.getProperty("hplen") != null){
			hairpin_len = Integer.valueOf(properties.getProperty("hplen").trim());
		}else{
			hairpin_len = 30; 
		}
		
		if(properties.getProperty("dplen") != null){
			minlen = Integer.valueOf(properties.getProperty("dplen").trim());
		}else{
			minlen = 11; 
		}
		if(properties.getProperty("buldge_gap") != null){
			unpair = Integer.valueOf(properties.getProperty("buldge_gap").trim());
		}else{
			unpair = 7; 
		}
		if(properties.getProperty("useheuristic") != null){
			useheuristic = Boolean.valueOf(properties.getProperty("useheuristic").trim());
		}
		theLogger.info(String.valueOf(useheuristic));
	}
	
	
	public static void main(String args[]) throws IOException {
		theLogger.setLevel(Level.OFF);
		
		Properties properties = new Properties(); 

		properties.load(new FileInputStream(args[4]));
		init(properties);
		
		
		
//		miRvial ob = new miRvial("test", "our", "cand", "simple");
		miRvial ob = new miRvial(args[0], args[1], args[2],args[3]);
		ob.filter();
//		ob.filter(args[0], args[1], args[2],args[3]);
	}
}

	

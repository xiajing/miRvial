import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

public class PreProcess {

	private static int mincopy = 5;	// minimum threshold for the peak read in a cluster
	private static int min_read_len = 20;
	private static int max_read_len = 30;
	
	static PrintWriter w = null;
	static PrintWriter w_2 = null;
	static BufferedReader chroReader = null;
	
	private static void init(Properties properties) {
		// TODO Auto-generated method stub
	
		// min copy number, when extract precursor, only consider reads having # >mincopy
		if(properties.getProperty("mincopy") != null){
			mincopy = Integer.valueOf(properties.getProperty("mincopy").trim());
		}else{
			mincopy = 5; 
		}
		
		if(properties.getProperty("min_read_len") != null){
			min_read_len = Integer.valueOf(properties.getProperty("min_read_len").trim());
		}else{
			min_read_len = 20; 
		}
		
		if(properties.getProperty("max_read_len") != null){
			max_read_len = Integer.valueOf(properties.getProperty("min_read_len").trim());
		}else{
			max_read_len = 30; 
		}
		
	}
	
	public static void preprocess(String infile) {
		// TODO Auto-generated method stub
		try {
			
			chroReader = new BufferedReader(new FileReader(infile));
			w = new PrintWriter("tmp.fa");
			
			String header = chroReader.readLine();
			String line = chroReader.readLine();

			while (header != null) {
			
					String str[] = header.split("_x");
					int len= line.length();
					
					if(Integer.valueOf(str[1])>=mincopy && len >= min_read_len && len <=max_read_len){
						w.println(header);
						w.println(line);
					}
				
					header = chroReader.readLine();
					line = chroReader.readLine();
			}
			w.flush();
			w.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void process_map(String infile) {
		try {
			
			
			chroReader = new BufferedReader(new FileReader(infile));
			w = new PrintWriter("tmp_p");
			w_2 = new PrintWriter("tmp_m");
			
			String line = chroReader.readLine();

			while (line != null) {
						if(line.contains("\t+\t")){
							w.println(line.replace("seq_x", ""));
						}
						if(line.contains("\t-\t")){
							w_2.println(line.replace("seq_x", ""));
						}
				
				
					line = chroReader.readLine();
			}
			w.flush(); w.close();
			w_2.flush(); w_2.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void process_map_adv(String infile) {
		try {
			chroReader = new BufferedReader(new FileReader(infile));
			w = new PrintWriter("tmp_p");
			w_2 = new PrintWriter("tmp_m");
			
			String line = chroReader.readLine();

			while (line != null) {
						String tmp[] = line.split("\t")[2].split("_");

						if(line.contains("\t+\t")){
							w.println(line+"\t"+tmp[tmp.length-1]);
						}
						if(line.contains("\t-\t")){
							w_2.println(line+"\t"+tmp[tmp.length-1]);
						}
				
				
					line = chroReader.readLine();
			}
			w.flush(); w.close();
			w_2.flush(); w_2.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String args[]) throws IOException {
		Properties properties = new Properties(); 
		properties.load(new FileInputStream(args[1]));
		init(properties);
		
		if (args[2].equals("PROCESS_READS")){
			preprocess(args[0]);
		}
		if (args[2].equals("PROCESS_MAP")){
			process_map(args[0]);
		}
		if (args[2].equals("PROCESS_MAP_ADV")){
			process_map_adv(args[0]);
		}
		
	}


}

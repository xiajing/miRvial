#!/bin/bash
java_r=$(which java)
#java_r="/home/jingxia/codes/java/jdk1.8.0_45/bin/java"

CLASSPATH="../src/"

## Parse alignment
[ ! -d ss/ ] && mkdir ss
[ ! -d str/ ] && mkdir str
NUM=$($java_r -cp ../src/ mfoldPlot $1 str ss) ## parse alignment
echo $NUM
exit
## Draw PS
for((i=1;i<=$NUM;i++))
do
../bin/b2ct <str/$i.str >ss/$i.ct  ## change vienna format to ct format. b2ct comes from Vienna package
../bin/sir_graph -rot 90 -png -p -ss-count -af ss/$i ss/$i.ct ## mfold generate figure`
done
#rm all.ps
for((i=1;i<=$NUM;i++))
do
#cat str/$i.ps >>all.ps
../bin/gnuplot_unix ./str/$i".gp"
done
#sed -e 's/1.0 1.0 scale/0.7 0.7 scale/g' all.ps >all_1.ps
#ps2pdf all_1.ps

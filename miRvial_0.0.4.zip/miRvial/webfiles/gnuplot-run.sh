#!/bin/bash

# note: this lives in Resources/bin

# get this script's directory
BINDIR=`dirname "$0"`
TOP="$BINDIR"/../../Resources

export PANGO_SYSCONFDIR="$TOP"/etc
export PANGO_RC_FILE="$TOP"/etc/pango/pangorc
export PANGO_LIBDIR="$TOP"/lib
export G_FILENAME_ENCODING=UTF-8

# location of gnuplot help file
export GNUHELP="$TOP"/share/gnuplot/5.0/gnuplot.gih
# location of PostScript resources
export GNUPLOT_PS_DIR="$TOP"/share/gnuplot/5.0/PostScript
# path to our version of AquaTerm
export AQUATERM_PATH="$BINDIR"/AquaTerm.app
# preferred terminal
export GNUTERM=wxt

export "PATH=$BINDIR:$PATH"

exec "$BINDIR"/gnuplot "$@"

<?php

class Alignment{

	public $st = 0;
	public $ed =0;
	public function __construct($ist /*...*/ ) {
             $this->st = $ist;
	}
}

function printAll($start, $end){
      	global $aligns; //will be defined in the load.php

	print '<div style="border; width:1500px; height: 500px; overflow: auto;">';
	print '<table style="font-family:courier new">';

	for($i = $start; $i<= $end; $i++){
        	$a = $aligns[$i]->st;
	        $b = $aligns[$i]->ed;
        	printAlignment($a, $b, $i);
	}
	print '</table>';
	print '</div>';

}

function printAlignment($a, $b, $i){
	global $lines; ////will be defined in the load.php

	print "<tr>  <td></td> <td nowrap align=left width=70 ><u># reads</u> <td nowrap align=left width = 70><u>length</u> </td> <td nowrap align=left width = 70><u># loci</u> </td> </tr>\n";
	
	$name = substr($lines[$a], 1, -1);
        print '<tr><td><a name="' .$i. '" href="#' .$i. '" onClick="f1(\'' .$i. '\');return false;">' .$name. '</a> &nbsp;|&nbsp;';


	print '<a name="ucsc browser" href="" onClick="ucsc(\'' .$name. '\'); return false;"> ucsc link </a> &nbsp;|&nbsp;';
	print '<input value="prev" type="button" onClick="window.location.href=\'#'.($i-1).'\'; return false;">';

	print '<input value="next" type="button" onClick="window.location.href=\'#'.($i+1).'\'; return false;"> </td></tr>';


//<input type="button" value="add" onclick=selectAdd(' .$i. ',"' .$name. '");></td></tr>';
        $a++;
	for(; $a<=$b; $a++){ 
		$arr = preg_split('/\s+/', $lines[$a]);
		print '<tr>';
		for($i =0 ;$i <sizeof($arr); $i++){
			print ' <td style="font-size:50%">'.$arr[$i].' </td>';
		}
		print "</tr>\n";
	}
}
?>


<?php

$rowsPerPage = 100;

$first ='';
$prev ='';
$nav  ='';
$next ='';
$last ='';


function getOffset($pageNum, $numrows){

global $rowsPerPage;
global $first;
global $prev;
global $nav;
global $next;
global $last;


// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;

// #numrows is in the load.php file
$maxPage = ceil($numrows/$rowsPerPage);

$self = $_SERVER['PHP_SELF'];


for($page = 1; $page <= $maxPage; $page++)
{
   if ($page == $pageNum)
   {
      $nav .= " $page "; // no need to create a link to current page
   }
   else
   {
#      $nav .= " <a href=\"$self?page=$page\">$page</a> ";
       $nav .= " <a href=\"\" onClick=\"ajaxFunction($page); return false;\">$page</a> ";

   }
}

if ($pageNum > 1)
{
   $page  = $pageNum - 1;
//   $prev  = " <a href=\"$self?page=$page\">[Prev]</a> ";
//   $first = " <a href=\"$self?page=1\">[First Page]</a> ";
 $prev  = " <a href=\"\" onClick=\" ajaxFunction($page); return false; \">[Prev]</a> ";
 $first = " <a href=\"\" onClick=\"ajaxFunction(1); return false;\">[First Page]</a> ";

}
else
{
   $prev  = "<a> [Prev]</a>"; //'&nbsp;'; // we're on page one, don't print previous link
   $first = "<a> [First Page]</a>";//'&nbsp;'; // nor the first page link
}

if ($pageNum < $maxPage)
{
   $page = $pageNum + 1;
   $next = " <a href=\"\" onClick=\"ajaxFunction($page); return false;\">[Next]</a> ";
   $last = " <a href=\"\" onClick=\"ajaxFunction($maxPage); return false;\">[Last Page]</a> ";
}
else
{
   $next = "<a> [Next]</a>";//'&nbsp;'; // we're on the last page, don't print next link
   $last = "<a> [Last Page]</a>"; // nor the last page link
}

return $offset;
}

?>

#step 0. rename the sequence
less /result/work/miRvial_supp/rawdata/Rice/R0.rmN.more10x.fasta|perl -e 'while(<>){chomp;if($_=~m/^>/){$_=~s/seq/seq\_/}print "$_\n";}' > rename.fasta
#step 1. map reads to genome
perl /result/pub/software/sRNA/mirdeep2/mapper.pl rename.fasta -c -j -l 16 -p /result/pub/database/rice/IRGSP1.0/irgsp-1.0.fasta -t res.arf -v 
#step 2. identification of miRNAs 
perl /result/pub/software/sRNA/mirdeep2/miRDeep2.pl rename.fasta /result/pub/database/rice/IRGSP1.0/irgsp-1.0.fasta  res.arf none none none 1>err 2>log


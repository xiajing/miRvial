#step 0. rename the sequence
less /results/work/miRvial_supp/rawdata/ninanjie/combin.rmN.more10x.fasta|perl -e 'while(<>){chomp;if($_=~m/^>/){$_=~s/seq/seq\_/}print "$_\n";}' > rename.fasta
#step 1. map reads to genome
mapper.pl rename.fasta -c -j -l 16 -p /results/pub/database/Arabidopsis_thaliana_ncbi/TAIR_20150904/TAIR10_format -t res.arf -v 
#step 2. identification of miRNAs 
miRDeep2.pl rename.fasta /results/pub/database/Arabidopsis_thaliana_ncbi/TAIR_20150904/TAIR10_format.fa res.arf none none none 1>err 2>log


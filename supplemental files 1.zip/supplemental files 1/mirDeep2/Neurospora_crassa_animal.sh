#step 0. rename the sequence
less /results/work/miRvial_supp/rawdata/Neurospora_crassa/Neurospora_crassa.rmN.more10x.fasta|perl -e 'while(<>){chomp;if($_=~m/^>/){$_=~s/seq/seq\_/}print "$_\n";}' > rename.fasta
#step 1. map reads to genome
mapper.pl rename.fasta -c -j -l 17 -p /results/pub/database/Neurospora_crassa/neurospora_crassa_or74a -t res.arf -v 
#step 2. identification of miRNAs 
miRDeep2.pl rename.fasta /results/pub/database/Neurospora_crassa/neurospora_crassa_or74a.fa res.arf none none none 1>err 2>log


tophat --num-threads 2 -o ./ --segment-length  18 /results/pub/database/Arabidopsis_thaliana_ncbi/TAIR_20150904/TAIR10  /results/work/miRvial_supp/rawdata/ninanjie/combin.rmN.more10x.fasta 1>tophat.log 2>tophat.err
samtools view -h  accepted_hits.bam > combin.sam
miRA full -c configuration.config_annotate combin.sam /results/pub/database/Arabidopsis_thaliana_ncbi/TAIR_20150904/TAIR10.fasta ./ 1>log 2>err

mkdir ref2;
 cd ref2;
 tophat --num-threads 2 -o ./ --segment-length  18 /result/pub/database/rice/IRGSP1.0/Chromosomes/ref2 /result/work/miRvial_supp/rawdata/Rice/R0.rmN.more10x.fasta 1> tophat.log 2>tophat.err;
 samtools view -h  accepted_hits.bam > combin.sam;
 miRA full -c ../configuration.config_annotate combin.sam /result/pub/database/rice/IRGSP1.0/Chromosomes/ref2.fasta ./ 1>log 2>err

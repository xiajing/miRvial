mkdir Supercontig_12.8;
 cd Supercontig_12.8;
 tophat --num-threads 2 -o ./ --segment-length  18 /results/pub/database/Neurospora_crassa/Chromosomes/Supercontig_12.8 /results/work/miRvial_supp/rawdata/Neurospora_crassa/Neurospora_crassa.rmN.more10x.fasta 1> tophat.log 2>tophat.err;
 samtools view -h  accepted_hits.bam > combin.sam;
 miRA full -c ../configuration.config_annotate combin.sam /results/pub/database/Neurospora_crassa/neurospora_crassa_or74a.fa ./ 1>log 2>err

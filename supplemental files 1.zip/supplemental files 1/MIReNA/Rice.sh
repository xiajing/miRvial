nohup  bash /result/pub/software/sRNA/MIReNA-2.0/MIReNA.sh -D -f rename.fasta -j /result/pub/database/rice/IRGSP1.0/irgsp-1.0.fasta -k microRNA4relatedSpecies.fa 1>log 2>err &
#nohup  bash /results/pub/software/sRNA/MIReNA-2.0/MIReNA.sh -D -f rename.fasta -j /results/pub/database/ppt/Ppatens_251_v3_format1.fa -k microRNA4relatedSpecies.fa -b bak_blastoutparsed 1>log 2>err &

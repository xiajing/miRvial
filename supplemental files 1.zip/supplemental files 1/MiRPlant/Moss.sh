nohup java -jar /results/pub/software/sRNA/miRPlant_command_line_V5/miRPlant_command_line.jar -g Ppt_251 -t 20 -l 24 all.fa 1>log  2>Err  &

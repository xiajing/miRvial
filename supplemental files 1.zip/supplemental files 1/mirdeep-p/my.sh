#!/usr/bin/bash

usage()
{
	echo Usage: `basename $0` \<-i IndexFile\> \<-g genomeFile\> \<-r ReadsFile\> \<-c cutoff4hitsNum\> [-o otdir] [-G ncRNA_CDS.gff] [-l precursor_length]
	echo "Required:
	IndexFile: bowtie-built index of the reference genome by bowtie-build (version 1).
	genomeFil: genome file used as reference;
	ReadsFile: fasta file of the sequencing reads in formate as follows:
		>seq_x100
		CTAGTTTTTTTTAAAAAAA
	cutoff4hitsNum: the maximum of hits a reads could mapped on the genome.

Optional:
	outdir       : out put directory. set to be current directory for default.
	ncRNA_CDS.gff: the miRNA annotation file in gff3 formate.
	precursor_length: the length of precursor, 250 bp for default.
	
	args should be correct"	
	exit 0
}

index="";
genome=""
readF=""
cutoff=0
otdir=`pwd`
gff=""
len=250

while getopts ":i:g:r:c:o:G:l:" optname
	do
		case "$optname" in
	    "i")
#			echo "Option $optname is specified"
			index=$OPTARG
		    ;;
		"g")
#			echo "Option $optname has value $OPTARG"
			genome=$OPTARG
			;;
		"r")
			readF=$OPTARG
			;;
		"c")
			cutoff=$OPTARG
			;;
		"o")
			otdir=$OPTARG
			;;
		"G")
			gff=$OPTARG
			;;
		"l")
			len=$OPTARG
			;;
		"?")
			echo "Unknown option $OPTARG"
			usage
			;;
		":")
			echo "No argument value for option $OPTARG"
			usage
			;;
		*)
		# Should not occur
			echo "Unknown error while processing options"
			usage
			;;
	esac
	#echo "OPTIND is now $OPTIND"
done

path='/results/pub/software/sRNA/miRDP1.3/'

if [[ -n "$index" && -n "$genome" && -n "$readF" ]]; then
	echo "We're good"
else
	usage
fi

if [ $cutoff -eq 0 ]; then
	usage
fi

if [[ -d $otdir ]]; then
	echo ""	
else
	mkdir $otdir
fi
	

echo  "bowtie -f –v 0 --all $index $readF >$otdir/AtShoot.aln"
bowtie -v 0 --all -f  $index $readF >$otdir/AtShoot.aln
$path/convert_bowtie_to_blast.pl $otdir/AtShoot.aln $readF $genome >$otdir/AtShoot.bst
$path/filter_alignments.pl $otdir/AtShoot.bst -c 15 >$otdir/AtShoot_filter15.bst

if [[ -n "$gff" ]]; then
$path/overlap.pl $otdir/AtShoot_filter15.bst $gff -b >$otdir/id_overlap_ncRNA_CDS
$path/alignedselected.pl $otdir/AtShoot_filter15.bst -g $otdir/id_overlap_ncRNA_CDS >$otdir/AtShoot_filter15_ncRNA_CDS.bst
$path/filter_alignments.pl $otdir/AtShoot_filter15_ncRNA_CDS.bst -b $readF > $otdir/AtShoot_filtered.fa
else
mv $otdir/AtShoot_filter15.bst $otdir/AtShoot_filter15_ncRNA_CDS.bst
fi

$path/excise_candidate.pl $genome $otdir/AtShoot_filter15_ncRNA_CDS.bst $len >$otdir/AtShoot_precursors.fa
cat $otdir/AtShoot_precursors.fa | RNAfold --noPS > $otdir/AtShoot_structures
bowtie-build -f $otdir/AtShoot_precursors.fa  $otdir/AtShoot_precursors

if [[ -n "$gff" ]]; then
bowtie -a -v 0 -f $otdir/AtShoot_precursors $otdir/AtShoot_filtered.fa > $otdir/AtShoot_precursors.aln
$path/convert_bowtie_to_blast.pl $otdir/AtShoot_precursors.aln $otdir/AtShoot_filtered.fa $otdir/AtShoot_precursors.fa > $otdir/AtShoot_precursors.bst
else
bowtie -a -v 0 -f $otdir/AtShoot_precursors $readF > $otdir/AtShoot_precursors.aln
$path/convert_bowtie_to_blast.pl $otdir/AtShoot_precursors.aln $readF $otdir/AtShoot_precursors.fa > $otdir/AtShoot_precursors.bst
fi

sort +3 -25 $otdir/AtShoot_precursors.bst >$otdir/AtShoot_signatures
$path/miRDP.pl $otdir/AtShoot_signatures $otdir/AtShoot_structures > $otdir/AtShoot_predictions

less $genome| perl -e  '$/=">"; <>; while(<>){chomp; ($id,@lines)=(split /\n+/,$_); $id=(split /\s+/,$_)[0]; $seq=join "",@lines; $len=length$seq; print "$id\t$len\n";}' >$otdir/chromosome_length
$path/rm_redundant_meet_plant.pl $otdir/chromosome_length $otdir/AtShoot_precursors.fa $otdir/AtShoot_predictions $otdir/AtShoot_nr_prediction $otdir/AtShoot_filter_P_prediction



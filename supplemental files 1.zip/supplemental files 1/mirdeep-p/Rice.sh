 nohup  bash  ../my.sh -i /result/pub/database/rice/IRGSP1.0/irgsp-1.0.fasta -g /result/pub/database/rice/IRGSP1.0/irgsp-1.0.fasta -r rename.fasta  -c 10  -o ./ -l 300 1>log 2>err &

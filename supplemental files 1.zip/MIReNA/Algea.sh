nohup  bash /results/pub/software/sRNA/MIReNA-2.0/MIReNA.sh -D -f all.fa -j /results/pub/database/cre/Creinhardtii_236_format1.fa -k microRNA4relatedSpecies.fa 1>log 2>err &




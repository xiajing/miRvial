microRNA4relatedSpecies.fa is an empty file.

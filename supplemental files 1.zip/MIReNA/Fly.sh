nohup  bash /results/pub/software/sRNA/MIReNA-2.0/MIReNA.sh -D -f rename.fasta -j /results/pub/database/Drosophila_melanogaster/dm6/dm6_format.fa -k microRNA4relatedSpecies.fa 1>log 2>err &

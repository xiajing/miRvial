mkdir ref11;
 cd ref11;
 tophat --num-threads 2 -o ./ --segment-length  18 /result/pub/database/rice/IRGSP1.0/Chromosomes/ref11 /result/work/miRvial_supp/rawdata/Rice/R0.rmN.more10x.fasta 1> tophat.log 2>tophat.err;
 samtools view -h  accepted_hits.bam > combin.sam;
 /home/lilun/Tools/miRA-1.2.0/miRA full -c ../configuration.config_lilun_annotate combin.sam /result/pub/database/rice/IRGSP1.0/Chromosomes/ref11.fasta ./ 1>log 2>err

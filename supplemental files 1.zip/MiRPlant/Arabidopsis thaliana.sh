 #nohup  java -jar /results/pub/software/sRNA/miRPlant_command_line_V5/miRPlant_command_line.jar -g TAIR10 -t 18 -l 35 /results/work/miRvial_supp/rawdata/Neurospora_crassa/Neurospora_crassa.rmN.fasta 1>log 2>Err &
nohup java -jar /results/pub/software/sRNA/miRPlant_command_line_V5/miRPlant_command_line.jar -g TAIR10_lilun -t 20 -l 24 all.fa 1>log  2>Err  &

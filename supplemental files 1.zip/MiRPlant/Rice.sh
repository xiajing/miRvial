nohup java -jar /result/pub/software/software/sRNA/miRPlant_command_line_V5/miRPlant_command_line.jar -g Rice  -t 20 -l 24 all.fa 1>log  2>Err  &

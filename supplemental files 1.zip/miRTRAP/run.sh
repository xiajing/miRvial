less /results/work/miRvial_supp/analysis/miRvial/ninanjie_10xReads/map | awk '{t++; print $3"\t.\t.\t"$4+1"\t"$4+length($5)"\t.\t"$2"\t.\tID="$1";"}' > reads.gff

echo "Print Read Region....";
perl /results/pub/software/sRNA/miRTRAP/Scripts/printReadRegions.pl  config.txt
echo "Done\n";

echo "Read Regions To RNAFold...";
perl /results/pub/software/sRNA/miRTRAP/Scripts/readRegionsToRNAFold.pl config.txt
echo "Done\n";

echo "RNAfold output to tt.mfe...";
cat tt.fasta |RNAfold --noPS > tt.mfe
echo "Done\n";


echo "Process Read Regions...";
perl /results/pub/software/sRNA/miRTRAP/Scripts/processReadRegions.pl config.txt
echo "Done\n";

echo "Evaluate Read Region With Genes...";
perl /results/pub/software/sRNA/miRTRAP/Scripts/evaluateReadRegionsWithGenes.pl config.txt gm.gff
echo "Done\n";

echo "Process Mir Regions...";
perl /results/pub/software/sRNA/miRTRAP/Scripts/processMirRegions.pl predicted_positives.txt reads.txt
echo "Done\n";


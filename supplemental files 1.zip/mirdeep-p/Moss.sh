 nohup  bash  ../my.sh -i /results/pub/database/ppt/Ppatens_251_v3_format1 -g /results/pub/database/ppt/Ppatens_251_v3_format1.fa -r rename.fasta  -c 10  -o ./ -l 300 1>log 2>err &

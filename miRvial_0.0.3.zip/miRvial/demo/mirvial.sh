#!/bin/bash

# CHANGE TO THE directory  of java class files
echo "running"
java_r=$(which java)
#java_r="/home/jingxia/codes/java/jdk1.8.0_45/bin/java"

rna_fold="../bin/RNAfold"
bowtie_j="../bin/bowtie"
bowtie_build_j="../bin/bowtie-build"

## param.txt should be in the same dir
## $1 human hg19 bowtie-built index
## $2 unique sequenceing reads
## $3 parameter file
##
if [[ -n "$1" && -n "$2" && -n "$3" ]]; then
echo "We're good"
else
echo "args should be correct"
exit
fi

### EDITING
../script/trimreads.sh $2 $3 >tmp.fa

## mapping
# -m int  important, the reads that will be considered
$bowtie_j $1 -n 0 -k 5 -m 10 --suppress 8 -f tmp.fa >map.tmp
sort -T ./ -k3,3 -k4,4n map.tmp >map.sort
rm map.tmp

# remove  known miRNA loci
if [[ -n "$4" ]]; then
$java_r -cp ../src/ RemoveLoci $4 map.sort map true
else
echo "error"
#mv map.sort map
fi

##
## extract sequences
grep -P "\t\+\t" map | sed 's/seq_x//' | sort -T ./ -k3,3 -k4,4n >tmp_s+

grep -P "\t-\t" map | sed 's/seq_x//'  | sort -T ./ -k3,3 -k4,4n >tmp_s-
rm tmp

$java_r -cp ../src/ -Xmx2G ScanMapExRegion tmp_s slide.fa $3
#awk '{if( $0 ~/>/){ tot++; print $0"_"tot;}else{print $0;} }' slide.fa >slide_1
#mv slide_1 slide.fa

## Folding
echo 'folding'
../bin/RNAfold --noPS <slide.fa >slide.str

## filter structure with higher energy
$java_r  -cp ../src/ FilterStr slide.str pre100.fa pre100.str $3



## map reads to extracted sequences; Draw alignment of reads
$bowtie_build_j pre100.fa pre100 >tmpout
rm tmpout
$bowtie_j pre100  -n 0 -a --suppress 8 -f $2  >topre.map --al topre.fa

echo 'RevCom'
$java_r  -cp ../src/ RevComNegRead topre.map topre_as.map

echo 'sorting and merge'
sort -T ./ -k5,5 topre_as.map >tmp1
#mv tmp1 topre_as.map
if [[ -n "$5" ]]; then
$java_r  -cp ../src/  Merge tmp1 $5 topre_as.map
else
mv tmp1 topre_as.map
fi

echo 'ready to draw'
cat topre_as.map | grep -P "\t\+\t" | awk '{l=split($3, a, "_"); print $0"\t"a[l];}' >tmp+
cat topre_as.map | grep -P "\t-\t"| awk '{l=split($3,a, "_"); print $0"\t"a[l];}' >tmp-
sort -T ./ -k8,8n tmp+ >topre_as.map+
sort -T ./ -k8,8n tmp- >topre_as.map-
rm tmp+ tmp-

# draw alignment
$java_r  -cp ../src/ DrawAlignment pre100.str topre_as.map+ topre_as.map- topre.map.align

# Post filter
$java_r  -cp ../src/ miRvial topre.map.align topre.map.align_1 cand simple $3



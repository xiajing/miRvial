function f1(i){
        var str= ""+i;
	var newImage = new Image();
	newImage.src = "./ss/"+str+".png#" + new Date().getTime();	
	var newplot = new Image();
	newplot.src = "./str/"+str+".png#" + new Date().getTime();	

 	document.getElementById("image").innerHTML ='<img src='+newImage.src+' width="500" height="700">';
	document.getElementById("fig").innerHTML= '<img src='+newplot.src+' width="500" height="350">';
//        document.getElementById("fig").innerHTML='<img src=./str/'+str+'.png  width="500" height="350" >';

//	document.getElementById("fig").src= newImage.src
}

function selectAdd(i,name){
        if(selList[i] != i){
                selList[i] = i;
        //for(var idx in )
                selected.innerHTML =  selected.innerHTML+ '<input type="checkbox" name="check_list" value="'+i+'" checked="true"><a href="#'+i+'>'+name+'</a><br></br>';
        }
}

function ucsc(str){
        var ts = str.split("_");
        var url = "http://genome.ucsc.edu/cgi-bin/hgTracks?db=hg19&position="+ts[0]+":"+ts[1]+"-"+ts[2];
        window.open(url);

}

function ajaxDownload(){
	var httpxml;

try
  {
  // Firefox, Opera 8.0+, Safari
  httpxml=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    httpxml=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    try
      {
      httpxml=new ActiveXObject("Microsoft.XMLHTTP");
      }
    catch (e)
      {
      alert("Your browser does not support AJAX!");
      return false;
      }
    }
  }

    function stateChanged()
        {
                 if(httpxml.readyState==4){
		  document.getElementById("selected").innerHTML="Done ....";
		}//if
        }// state chan


        var url="download.php";	
	httpxml.onreadystatechange=stateChanged;
	httpxml.open("GET",url,true);
	httpxml.send(null);
  document.getElementById("selected").innerHTML="Please Wait....";


}

function ajaxFunction(val)
{
//val selVal  = document.getElementById("sel").value;
//document.writeln(val)
	var httpxml;
try {
  // Firefox, Opera 8.0+, Safari
  	httpxml=new XMLHttpRequest();
}catch (e) {
  // Internet Explorer
  try{
    	httpxml=new ActiveXObject("Msxml2.XMLHTTP");
  }catch (e){
    try{
      	httpxml=new ActiveXObject("Microsoft.XMLHTTP");
    }catch (e){
      	alert("Your browser does not support AJAX!");
     	 return false;
    }
  }
}


function stateChanged() {
    if(httpxml.readyState==4){
	document.getElementById("txtHint").innerHTML=httpxml.responseText;
    }//if
}// state changed

var selList = new Array();

var url="load.php";
url=url+"?page="+val;
httpxml.onreadystatechange=stateChanged;
httpxml.open("GET",url,true);
httpxml.send(null);
document.getElementById("txtHint").innerHTML="Please Wait....";
}



<h3><font color="#ff0000">Visualization of novel microRNAs. </font></h3>

<html>
<head>
  <meta charset="utf-8">
  <title>Pipeline</title>
  <script type="text/javascript" src="script1.js"></script>
</head>

<body onload="ajaxFunction('1')";> 

<h3> Alignment</h3>
<div id="txtHint">
</div>

<!--image  -->
<h3> Secondary structure</h3>
<div id="image">
<img  width="500" height="350" >
</div>

<h3> Reads distribution</h3>
<div id="fig">
<img  width="500" height="350" >
</div>


</body>
</html>


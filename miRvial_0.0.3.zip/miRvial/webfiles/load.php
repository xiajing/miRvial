
<?php
#ini_set("memory_limit","128M");
require_once('alignclass.php');
require_once('page.php');


# text file result form miRvial
$myFile = "./input.txt";

$lines = array();
$count = 0;
$handle = fopen($myFile, 'r') or die ("change the name of miRvial result to input.txt ");
if ($handle) {
    while (!feof($handle)) {
        $buffer = fgets($handle);
        $lines[$count] = $buffer;
        $count++;
    }
    fclose($handle);
}


$aligns = array();  // define $aligns in alignclass.php

$alignID = 1;
$count = count($lines);

# count how many blocks of alignments are in the file
for($i=0; $i<$count; $i++){
        if(strpos($lines[$i], ">") !== FALSE){
                $tmp = new Alignment($i);
                $i++;

                for(; $i <$count && (strpos($lines[$i], ">") === FALSE) ; $i++ ) {

                }
                $i--;
                $tmp->ed = $i;
                $aligns[$alignID] = $tmp;
                $alignID++;
        }
}

// numrows will be used for paging in the index.php
$numrows = $alignID-1;
echo "# of records: ".$numrows."</br>";


// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
   $pageNum = $_GET['page'];
   echo "page # ".$pageNum."</br>";
}

//  numrows is in load.php
$offset = getOffset($pageNum, $numrows);

if($offset+$rowsPerPage<=$numrows){
	echo $offset."\t".$pageNum."\t".
	// $rowsPerPage in page.php
	// function in alignclass.php
	printAll($offset+1, $offset+$rowsPerPage);
}else{
	printAll($offset+1, $numrows);
}

// print the navigation link
print '<div>';
print $first . $prev . $nav . $next . $last;
print '</div>';

?>

../bin/RNAfold --noPS <$1 >$1.out

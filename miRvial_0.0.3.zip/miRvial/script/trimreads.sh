minc=`awk '{if($0~/mincopy/){split($0,a,"="); print a[2]}}' $2`
llen=`awk '{if($0~/min_read_len/){split($0,a,"="); print a[2]}}' $2`
xlen=`awk '{if($0~/max_read_len/){split($0,a,"="); print a[2]}}' $2`
#echo $minc" "$llen" "$xlen

tr -d '\15\32' <$1 |  sed -e 'N;s/\n/\t/;s/_x/_x\t/g;P;D' | awk -F "\t" -v cpn="$minc" -v llen="$llen" -v xlen="$xlen" '{
        if(length($3)>=llen && length($3)<=xlen && $2>=cpn){ print $0;}
}'  | sed -e 's/_x\t/_x/g;s/\t/\n/g'


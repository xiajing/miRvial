#!/bin/sh
geno=$2
java_r=$(which java)
#java_r="/home/jingxia/codes/java/jdk1.8.0_45/bin/java"

echo $PWD
which java
bowtie_j="../bin/bowtie"
bowtie_build_j="../bin/bowtie-build"

$bowtie_j -p 6 $geno -n 0 --norc  -f $1 >$1_norc
$bowtie_j -p 6 $geno -n 0 --nofw  -f $1 >$1_nofw
$java_r -version
$java_r -cp ../src/ RevComNegRead $1_nofw $1_nofw_rc
cat $1_norc $1_nofw_rc | sort +4 -5 >tmp2
$java_r -cp ../src/  Unique tmp2 $1_lib


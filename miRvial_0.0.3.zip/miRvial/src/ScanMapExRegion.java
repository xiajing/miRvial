import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Properties;


// scan map file and extract potential hotspots' regions
public class ScanMapExRegion {
	
	// 5' 3' extension = size of sliding window 
	public static int l_extLen = 100;
	public static int s_extLen = 50;

//	public static int slideLen = 10; 
//	public static int slidespan = 50;

	
	// gap length
	public static int gapLen = 5; 

	// min copy number, when extract precursor, only consider reads having # >mincopy
	public static int mincopy = 5; 

	// gneomic loci
	public static String dir = "C:/Users/think/datahouse/hg19/"; // needs paramter
	public static boolean isDir = false;
	
	//	
	//public static int allcopy = 10; 

	public static boolean isminus = false;
	
	private static int count = 1;
	private BufferedReader reader;
	// read map files
//  bowtie map file format 
	// seq359_x1       -       chr22   148     AATTTTT IIIIIII 0
    // chromNum is the number of chromosomes
	public void read3(String fn, PrintWriter w){
		
		HashMap<Integer, Integer> loci = new HashMap<Integer, Integer>();
		PriorityQueue<Integer> pq = new PriorityQueue<Integer>();
		
		try {
			reader = new BufferedReader(new FileReader(fn));
			String s = reader.readLine();
			
			if(s==null){ reader.close(); return; }		
			String strs[] = s.trim().split("\t");
			if(strs[1].equals("-")) isminus = true;
			
			String curr = strs[2];
			int info[] = getInfo(strs); //genomic loci
			addpos(info[0], info[1], info[2], loci, pq );
			s = reader.readLine();
			
			while(s != null){
				
				strs = s.trim().split("\t");
				if(curr.equals(strs[2])){
					
				}else{
					scanWrite(w, loci, pq, curr);
					loci = new HashMap<Integer, Integer>(); pq = new PriorityQueue<Integer>();
					curr = strs[2];
				}
				
				info = getInfo(strs);
				addpos(info[0], info[1], info[2], loci, pq );				
				s = reader.readLine();
				
			}
			if(pq.size() != 0){
				scanWrite(w, loci, pq, curr);
			}

		//	w.flush(); w.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	private int[] getInfo(String[] strs) {
		// TODO Auto-generated method stub
		int ret[] = new int[3];
		String ts[] = null;
		if(strs[0].contains("_x")){
			ts = strs[0].split("_x");
		}else{
			ts = strs[0].split("_");
		}
		
		if(ts.length==2){ret[2] = Integer.valueOf(ts[1]);}
		else{ret[2] = Integer.valueOf(ts[0]); }
		ret[0] = Integer.valueOf(strs[3])+1; //bowtie result =>> genomic loci
		ret[1] = Integer.valueOf(ret[0] + strs[4].length() - 1);
		return ret;
	}

	private void addpos(int st, int ed, int num, HashMap<Integer, Integer> map, PriorityQueue<Integer> pq) {
		// TODO Auto-generated method stub		
		if(num >= mincopy){}
		else{
			return;
		}
		
		for(int i = st; i <= ed; i++){
			if(map.containsKey(i)){
				int locnum = (Integer)map.get(i);			
				locnum += num;
				map.put(i, locnum);
				
			}else{
				map.put(i, num);
				pq.add(i); //genomic loci; might be minus due to extesion
			}
		}
	}
	
		
	public LinkedList<String> scanandExtract(HashMap<Integer, Integer> loci, PriorityQueue<Integer> pq){
		LinkedList<String> prelist = new LinkedList<String>();
		//genomic loci
		if(pq.size() == 0) {
			System.err.println("Nothing to extract");
			return prelist;
		}
		int pos = (Integer) pq.remove();
		
		int start = pos;
		int curr = pos;

		while (!pq.isEmpty()) {
			pos = (Integer) pq.remove();
			if (pos - curr > gapLen) {
				int end = curr;
				prelist.add(start+"\t"+end);
				start = pos;
			}
			curr = pos;
		}
		int end = curr;
		prelist.add(start+"\t"+end);
		return prelist;
	}
	
	// fn is the file including regions with potential miNRA
	// format of fn st end
	/*public void excise(String chr, PrintWriter w, LinkedList list, boolean isminus){
		
		for(int i = 0; i < list.size(); i++){
			//genomic loci
			String pos[] = ((String)list.get(i)).split("\t");
			int st = Integer.valueOf(pos[0]) - l_extLen; 
			int ed = Integer.valueOf(pos[1])+ l_extLen;
			int strand = 1;
			if(isminus){
				strand =2;
			}
			String str = Exgenomeseq.seqExtract(chr, st, ed, strand, dir, isDir);
			w.println(">"+chr+"_"+st+"_"+ed+"_"+strand);
			w.println(str);
		}
		
	}*/

	private void slideEx1(String chr, PrintWriter w, LinkedList<String> list, boolean isminus){
		 for(int i = 0; i < list.size(); i++){
			 String pos[] = ((String)list.get(i)).split("\t");
                        int st = Integer.valueOf(pos[0]);
                        int ed = Integer.valueOf(pos[1]);
                        int strand = 1;
                        if(isminus){
                                strand =2;
                        }
                        
                        int st1 = st - l_extLen;
                        int ed1 = ed + s_extLen;
                              
                        String str = Exgenomeseq.seqExtract(chr, st1, ed1, strand, dir, isDir);
                        w.println(">"+chr+"_"+st1+"_"+ed1+"_"+strand+"_"+count);
                        w.println(str);
                        count++;
                        
                        st1 = st - s_extLen; 
                        ed1 = ed + l_extLen;
                     
                        str = Exgenomeseq.seqExtract(chr, st1, ed1, strand, dir, isDir);
                        
                        w.println(">"+chr+"_"+st1+"_"+ed1+"_"+strand+"_"+count);
                        w.println(str);
                        count++;

		}
	}	
/*	private void slideEx(String chr, PrintWriter w, LinkedList list, boolean isminus){
		for(int i = 0; i < list.size(); i++){
			//genomic loci
			String pos[] = ((String)list.get(i)).split("\t");
			int st = Integer.valueOf(pos[0])- extLen; 
			int ed = Integer.valueOf(pos[1])+ extLen;
			int strand = 1;
			if(isminus){
				strand =2;
			}
			String str = Exgenomeseq.seqExtract(chr, st, ed, strand, dir, isDir);
	
			if(st < 0){ st = 1;}
			if(ed > Exgenomeseq.genome.length()) {ed = Exgenomeseq.genome.length();}
			
			
			int j = st;
			if(isminus){
				j = ed - slidespan + 1;
			}
		
			if(str.length()- slidespan < 0){
				w.println(">"+chr+"_"+st+"_"+ed+"_"+strand);
				w.println(str);
			}	
			// original int j =st, n=0 ; j <= ed- extLen; j+=slideLen,n+=slideLen 
			for(int n=0 ; n <= str.length()- slidespan; n=n+slideLen ){
				// genomic loci
				w.println(">"+chr+"_"+j+"_"+(j+slidespan-1)+"_"+strand);
				w.println(str.substring(n, n+slidespan));
				if(isminus){
					j=j-slideLen;
				}else{
					j=j+slideLen;
				}

			}	
		
		}
	}*/
	
	private void scanWrite(PrintWriter w, HashMap<Integer, Integer> loci, PriorityQueue<Integer> pq, String chro) {
		// TODO Auto-generated method stub
		LinkedList<String> list = scanandExtract(loci, pq);
		// slide first
//		if(slidespan==-1){
			slideEx1(chro, w, list,  isminus);
//		}else{
//			slideEx(chro, w, list,  isminus);
//		}
	}


	private static void init(Properties properties) {
		// TODO Auto-generated method stub
		if(properties.getProperty("extLen") != null){
			l_extLen = Integer.valueOf(properties.getProperty("extLen"));
		}else{
			l_extLen = 100;  // default
		}
		
		if(properties.getProperty("slideLen") != null){
//			slideLen = Integer.valueOf(properties.getProperty("slideLen"));
		}else{
//			slideLen = 10; 
		}
				
		// gap length
		if(properties.getProperty("gapLen") != null){
			gapLen = Integer.valueOf(properties.getProperty("gapLen"));
		}else{
			gapLen = 30; 
		}

		// min copy number, when extract precursor, only consider reads having # >mincopy
		if(properties.getProperty("mincopy") != null){
			mincopy = Integer.valueOf(properties.getProperty("mincopy"));
		}else{
			mincopy = 10; 
		}
		
		if(properties.getProperty("gendir") != null){
			dir =properties.getProperty("gendir").trim();//+"/";
		}else{
			dir = "./"; 
		}
		
		 // min copy number, when extract precursor, only consider reads having # >mincopy
                if(properties.getProperty("slidespan") != null){
 //                       slidespan = Integer.valueOf(properties.getProperty("slidespan"));
                }else{
//                        slidespan = 50;
                }
		if(properties.getProperty("isDir") != null){
			isDir =Boolean.valueOf(properties.getProperty("isDir").trim());
		}else{
			isDir = false; 
		}
		System.err.println("extLen="+l_extLen);
//		 System.err.println("slideLen="+slideLen);
//		System.err.println("slidespan="+slidespan);
		System.err.println("gaplen="+gapLen);
	}
	
	public static void main(String args[]) throws IOException {
		// TODO Auto-generated method stub
		Properties properties = new Properties(); 
//		properties.load(new FileInputStream("./param.txt"));
		properties.load(new FileInputStream(args[2]));		
		init(properties);
		System.out.println(dir+ "\t"+isDir);
		
		//args[0];
	
		PrintWriter w = new PrintWriter(args[1]);
		ScanMapExRegion ob = new ScanMapExRegion();
		ob.read3(args[0]+"+", w);
		w.flush();
		ob.read3(args[0]+"-", w);
		w.flush(); w.close();
	}


}

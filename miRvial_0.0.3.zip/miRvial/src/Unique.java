import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;


public class Unique {
        public static void readin(String fn, String out){
                BufferedReader reader;
                try {
                        reader = new BufferedReader(new FileReader(fn));
                        PrintWriter w = new PrintWriter(out);

                        String s = reader.readLine();
                        String tmps[] = s.trim().split("\t");

                        String curr = tmps[4];
                        String curs[] = tmps;
                        int val = Integer.valueOf(tmps[6])+1;
                        s = reader.readLine();

                        while (s != null) {
                                tmps = s.trim().split("\t");
                                if(tmps.length <2)System.out.print(s);
                                if(!tmps[4].equals(curr)){
                                        for(int i = 0; i < curs.length-1; i++){
                                                w.print(curs[i]+"\t");
                                        }
                                        w.println(val);
                                        curr = tmps[4]; curs = tmps; val = Integer.valueOf(tmps[6])+1;

                                }else{
                                        val += (Integer.valueOf(tmps[6]) + 1);
                                }
                                s = reader.readLine();
                        }
                        for(int i = 0; i < curs.length-1; i++){
                            w.print(curs[i]+"\t");
                        }
                        w.println(val);
                        w.flush(); w.close();
                } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }
        }

        public static  void main(String args[]){
                readin(args[0], args[1]);
        }
}


/**
    miRvial - miRNAs via integrative analysis
    Copyright (C) 2015 

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 **/

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Stack;


public class AlignmentFunction {

	public static Alignment getBlock(Alignment ret, String s, BufferedReader chroReader) throws IOException {
		// TODO Auto-generated method stub
		String title =s;
		String seq = chroReader.readLine();
		ret.seq = seq;
		ret.name = title;
		int p_count=0;
		
		boolean flag = false;
		s = chroReader.readLine();
		while(s != null && s.length() != 0 && !s.contains(">") ){
			if(s.contains("negative")){
				flag = true;
				s = chroReader.readLine();
				continue;
			}
			if(!s.matches("\\.*[AGCTUagctu]+\\.*(\\s+[0-9]+)*([0-9]*:.+)?")){
				ret.strc.add(s);
			}else{
				if(flag){
					ret.mreads.add(s);
				}else{
					ret.preads.add(s);					
					
					ret = lineProcess(ret, s, p_count);
					p_count++;
				}
			}
			s = chroReader.readLine();
		}
		ret.cursor = s;
		return ret;
	}

	private static Alignment lineProcess(Alignment ret, String s, int p_count ) {
		// TODO Auto-generated method stub
		String strtmp[]=s.split("\\s+"); 
		
		int a = strtmp[0].split("[agctuAGCTU]+")[0].length(); //0-based
		int b = a + strtmp[0].replace(".", "").length() - 1;	// 0-based				
		ret.preads_coords.add(a);ret.preads_coords.add(b);
		
		int tmp = Integer.valueOf(strtmp[1]);
		if(tmp >= ret.pread_max){
			ret.pread_maxid = p_count; ret.pread_max = tmp;
		}
		return ret;
	}
	
	
	//1-based
	public static int[]  getPair(String strcure) {
		// TODO Auto-generated method stub	
		//int len = strcure.length()+1;
		 Stack<Object> st = new Stack<Object>();
		
		char strc[] = strcure.split("\\s+")[0].toCharArray();
		int pair[] = new int[strc.length+1];
		
		for(int i = 0 ; i < strc.length; i++){
			switch(strc[i]){
			case '.': {continue;}
			case '(': {st.push(i+1); continue;}
			case ')': {int l = (Integer)st.pop();
			 			pair[i+1] = l; pair[l] = i+1;
					continue;}
			}
		}
		return pair;
	}
	
	public static LinkedList<int[]> getStemsRecursive(String s, LinkedList<int[]> l){
		
		int c = 0;
		char charr[] = s.toCharArray();
		for(int i =0 ; i< charr.length; i++){
			if(charr[i]=='.'){c++;}
		}
		
		if(c==charr.length) return l;
			
		String arr[]=s.split("\\(\\.*\\)");
		
		
		int coords [] = new int [4]; // 0 -based
		coords[1]= arr[0].length();
		coords[2] =s.length() -  arr[1].length() -1 ;
		
		int tmp = arr[0].length();
		for(int  i = arr[0].length(); i>=0; i-- ){
			if(charr[i] == '('){tmp = i;}
			if(charr[i] == ')'){break;}
		}
		coords[0] = tmp;
		// from right to 
		tmp = coords[2];
		for(int  i = coords[2]; i<s.length(); i++ ){
			if(charr[i] == ')'){tmp = i;}
			if(charr[i] == '('){break;}
		}
		coords[3] = tmp;
		System.out.println(coords[0]+"\t"+coords[1]+"\t"+coords[2]+"\t"+coords[3]);
		l.add(coords);
		
		for(int i = coords[0]; i<=coords[3]; i++){
			charr[i] ='.';
		}
		l = getStemsRecursive(String.valueOf(charr), l);
		return l;
	}
	
	public static LinkedList<int[]> getStems(int a, int b, int[] pair_t, int buldge_gap) {
		// TODO Auto-generated method stub
		int prev = 0; int max = 0; int cont_len=0;
		int coor[] = new int[2];
		LinkedList<int[]> l = new LinkedList<int[]>();
		int ret[] = new int[3]; 
		
		int num_p = 0;
		int num_unpaired = 0;
		
		int pair[] = new int[pair_t.length];
		for(int i = 0; i<pair.length;i++){pair[i] = pair_t[i];}
		
		cont_len=1; int i=a;
		for(; i<=b;i++){
			if(pair[i+1]==0){continue; }
			else{	
				coor[0] = pair[i+1];  coor[1] = pair[i+1]; prev = pair[i+1]; 
				break;
			}	
		}
		
		for(; i<=b;i++){
			if(pair[i+1]==0){
				num_unpaired++;
				continue; 
			}
			else{				
					// setting ****************
					int tmp = Math.abs(prev-pair[i+1]); 
					if( tmp  <= buldge_gap+1 && num_unpaired <= buldge_gap ){ 
						cont_len+=tmp;  coor[1] = pair[i+1]; num_p++;
					} //*************
					else{
	//					if(num_p>max){
	//						max=num_p; 
							ret[0]= coor[0]; ret[1]=coor[1]; ret[2]=num_p;
							l.add(ret);
	//					}
						ret = new int[3]; 
						cont_len = 1; coor[0] = pair[i+1];  coor[1] = pair[i+1]; num_p=1;
					}
				
				prev = pair[i+1]; pair[pair[i+1]]=0;  num_unpaired=0;
			} 
		}
		
		if(num_p>max){max=cont_len; ret[0]= coor[0]; ret[1]=coor[1]; ret[2]=num_p;
			l.add(ret);
		}
		return l;
	}
	
	public static void write(PrintWriter w, Alignment al) {
		// TODO Auto-generated method stub
		if(al.strc.size() >0){
			w.println(al.name);
			if(al.seq.contains("U")) al.seq = al.seq.replace("U", "T");
			w.println(al.seq);
			for(int i = 0 ; i < al.strc.size(); i++) w.println((String)al.strc.get(i));
			for(int i = 0 ; i < al.preads.size(); i++) w.println((String)al.preads.get(i));
			w.println("negative");
			for(int i = 0 ; i < al.mreads.size(); i++) w.println((String)al.mreads.get(i));

		}
	}

	
	public static void main(String args[]){
		String str = ".........(((.(((((....(((((..(((((.(((.((......)).........(((((((((((..(((((((((..((.(((((((.((............)).)))))))))..)))))).((((.....)))).)))..))))))))))).))).))))).(((((((..(((....))).)))))))...))))).....))))))))....((.((.(((.(((((((((..((((..((....))..))))..))))))))).))).)).))";
		int pair[] = getPair(str);
		//	str = ".(((.))).";
		LinkedList<int[]> l  = getStems(0, str.length()-1, pair, 8);
		for(int i = 0; i<l.size();i++){
			int[] a= (int[])l.get(i);
			System.out.println(a[0]+"\t"+a[1]+"\t"+a[2]);
		}
		//LinkedList l  = getStemsRecursive(str, new /());
		
	}
	
}



import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Properties;
import java.util.HashMap;

public class FilterStr {

	public static double mindG  = 18;
	
//	public static int hplen  = 18;

//	public static int pre_id = 0;
	//public static int buldge  = 5;
	
	public FilterStr(String pa){
		Properties properties = new Properties(); 
		try {
			properties.load(new FileInputStream(pa));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		mindG  = Integer.valueOf( properties.getProperty("mindg"));
//		hplen  = Integer.valueOf( properties.getProperty("hplen"));
	}
	
	public static Alignment getBlock(Alignment ret, String s, BufferedReader chroReader) throws IOException {
		// TODO Auto-generated method stub
		String title =s;
		String seq = chroReader.readLine();
		ret.seq = seq;
		ret.name = title;
		int p_count=0;
		
		boolean flag = false;
		s = chroReader.readLine();
		while(s != null && s.length() != 0 && !s.contains(">") ){
			if(s.contains("negative")){
				flag = true;
				s = chroReader.readLine();
				continue;
			}
			if(!s.matches("\\.*[AGCTUagctu]+\\.*(\\s+[0-9]+)*([0-9]*:.+)?")){
				ret.strc.add(s);
			}else{
				if(flag){
					ret.mreads.add(s);
				}else{
					ret.preads.add(s);					
					String strtmp[]=s.split("\\s+"); 
					
					int a = strtmp[0].split("[agctuAGCTU]+")[0].length(); //0-based
					int b = a + strtmp[0].replace(".", "").length() - 1;	// 0-based				
					ret.preads_coords.add(a);ret.preads_coords.add(b);
					
					int tmp = Integer.valueOf(strtmp[1]);
					if(tmp >= ret.pread_max){
						ret.pread_maxid = p_count; ret.pread_max = tmp;
					}
					p_count++;
				}
			}
			s = chroReader.readLine();
		}
		ret.cursor = s;
		return ret;
	}
	
	// select dG < energy,  and secture.
	public void filter(String dir, String out, String struc) {
		try {
			BufferedReader chroReader = new BufferedReader(new FileReader(dir));
			PrintWriter w = new PrintWriter(out);
			PrintWriter w1 = new PrintWriter(struc);
			String s = chroReader.readLine();

			while (s != null) {
				
				if(s.contains(">")){
					Alignment al = new Alignment();
					al = getBlock(al, s, chroReader);
					s = al.cursor;
					al = filterSecStr(al);
					write2FA(w, al);
					write2Struc(w1, al);
				//	pre_id++;
				}else{
					s = chroReader.readLine();

				}
		
			}
			w.flush(); w.close(); w1.flush(); w1.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void write2FA(PrintWriter w, Alignment al) {
		// TODO Auto-generated method stub
		if(al.strc.size() >0){
			w.println(al.name);
			al.seq = al.seq.replace("U", "T");
			al.seq = al.seq.replace("u", "t");
			w.println(al.seq);
		//	w.println((String)al.strc.get(0));
		}
	}

        private void write2Struc(PrintWriter w, Alignment al) {
                // TODO Auto-generated method stub
                if(al.strc.size() >0){
                        w.println(al.name);
			al.seq = al.seq.replace("T", "U");
			al.seq = al.seq.replace("t", "u");
                        w.println(al.seq);
                        for(int i = 0 ; i < al.strc.size(); i++) w.println((String)al.strc.get(i));
                }
        }


	public static void write(PrintWriter w, Alignment al) {
		// TODO Auto-generated method stub
		if(al.strc.size() >0){
			w.println(al.name);
			al.seq = al.seq.replace("U", "T");
			al.seq = al.seq.replace("u", "t");
			w.println(al.seq);
			for(int i = 0 ; i < al.strc.size(); i++) w.println((String)al.strc.get(i));
			for(int i = 0 ; i < al.preads.size(); i++) w.println((String)al.preads.get(i));
			w.println("negative");
			for(int i = 0 ; i < al.mreads.size(); i++) w.println((String)al.mreads.get(i));

		}
	}

	private Alignment filterSecStr(Alignment al) {
		// TODO Auto-generated method stub
		int len = al.strc.size(); HashMap<Integer, Integer> tmpL = new HashMap<Integer, Integer>();
		for(int i = 0; i< len; i++){
			String s = (String)al.strc.get(i);
			String tmps[] = s.split("\\s+"); if(tmps.length <2)System.err.println(al.name);
			String tmp = tmps[tmps.length-1].replaceAll("[\\(\\)-]", "");
			if(tmp.equals(""))System.err.println(al.name);
			double num = Double.valueOf(tmp);
			
		//	if(num >mindG && hashaipin(tmps[0])){
			if(num >mindG ){	
			}else{
				tmpL.put(i,i);
			}
		}
		LinkedList<String> ll = new LinkedList<String>();
		for(int i = 0; i< len; i++){
			if(!tmpL.containsKey(i) ) {
				ll.add((String)al.strc.get(i));
			}	
		}
		al.strc = ll;
		return al;
	}

	/*
	private boolean hashaipin(String str) {
		// TODO Auto-generated method stub  
		String tmp = str.replaceAll("\\(\\.+\\)", "\\(#\\)");
		String s[] = tmp.split("#");
		
		for(int i =0; i < s.length -1; i++){
			String ts1[] = s[i].replace(")", "").split("^\\.*");
			String s1 = ts1[ts1.length-1];
			
			String s2 = s[i+1].replace("(", "").split("\\.*$")[0];
			int l1 = s1.length(); 
			int l2 = s2.length();
			
			s1 = s1.replace(".", "");
			s2 = s2.replace(".", "");
			
			int pairlen = Math.min(s1.length(), s2.length());
			int pairlen_2= Math.max(s1.length(), s2.length()) - pairlen;

			int points = Math.max(l1- s1.length() , l2 -s2.length() );
			
			if(pairlen >= hplen  || pairlen_2 >= hplen ){// && points <= buldge){
				return true;
			}
		}
		
		return false;
	}*/



	public static void main(String args[]) throws FileNotFoundException {
		FilterStr ob = new FilterStr(args[3]);
	//	System.out.println("hplen\t"+hplen);
		ob.filter(args[0], args[1], args[2]);
	}	
}

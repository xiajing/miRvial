import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Stack;


public class mfoldPlot {

	
		public static void readin1(String fn, String dir, String ssdir){
			try {
				BufferedReader reader = new BufferedReader(new FileReader(fn));
				PrintWriter w =null; 
				PrintWriter w1 = null; 
				PrintWriter w2 = null;
				PrintWriter w3 = null;
				
				if(!dir.endsWith("/"))dir=dir+"/";
				if(!ssdir.endsWith("/"))ssdir=ssdir+"/";	
				int count = 1;
				String s = reader.readLine(); 
				while(s != null){
					if(s.contains(">")){
						Alignment al = new Alignment();
						al = FilterStr.getBlock(al, s, reader);
										
						s = al.cursor;
						w = new PrintWriter(ssdir+count+".ss-count");
						w1 = new PrintWriter(dir+count+".str");
						w2 = new PrintWriter(dir+count+".dat");
						w3 = new PrintWriter(dir+count+".gp");
						
						writeAnn(al, w);
						genSth(w2, al);
						writegp(w3, al, count, dir);
						
						w1.println(al.name);
						w1.println(al.seq);
						w1.println((String)al.strc.get(0));
						w1.flush(); w1.close(); 
						w2.flush(); w2.close(); w3.flush(); w3.close();
						count++;
					}else{
						s = reader.readLine();
					}				
				}
				
				System.out.println(count-1);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		private static void writegp(PrintWriter w3, Alignment al, int count, String dir) {
			// TODO Auto-generated method stub
			w3.println("set terminal png");
			w3.println("set output \""+ dir + count + ".png\"");
			w3.println("set style line 1 lt 2");
			String str= al.name; ;//ts[0].replace(">", "")+":"+ts[1]+"-"+ts[2]+" "+ts[3]+" "+ts[4];
			//str.replaceAll("_","\\\\\\_");
			w3.println("set title \""+ str + "\"");
			w3.println("set xtics 0,20");w3.println("set nokey");
			w3.println("plot '"+ dir + count + ".dat' using 2 with linespoints lt 1" );
		}
	
		private static void genSth(PrintWriter w, Alignment al) {
			// TODO Auto-generated method stub
			String title = al.name;				
			String seq = al.seq;
			
			char arr[] = seq.toCharArray();
			int acc[] = new int[arr.length];
				
			w.println(title.substring(1));
		
			for(int i = 0; i < al.preads.size(); i++){
				String tmps[] =  ((String)al.preads.get(i)).split("\\s+");
				if(tmps.length <1)System.out.print(al.name);
				int num = Integer.valueOf(tmps[1]);
				char tmparr[] = tmps[0].toCharArray();
				
				for(int j = 0; j < tmparr.length; j++){
					if(tmparr[j] != '.'){
						acc[j] += num;
					}
				}
			}
			// write 
			for(int i = 0; i < acc.length; i++){					
				//w.println(arr[i] +"\t" + Math.log(acc[i]+1));	
				w.println(arr[i] +"\t"+acc[i]);
			}
			w.flush(); w.close();
		}
		
		private static int[]  getPair(Alignment al) {
			// TODO Auto-generated method stub
			int len = al.seq.length();
			
			int pair[] = new int[len]; Stack<Integer> st = new Stack<Integer>();
			char strc[] = ((String)al.strc.get(0)).split("\\s+")[0].toCharArray();
			for(int i = 0 ; i < strc.length; i++){
				switch(strc[i]){
				case '.': {continue;}
				case '(': {st.push(i); continue;}
				case ')': {int l = (Integer)st.pop();
				 			pair[i] = l; pair[l] = i;
						continue;}
				}
			}
			return pair;
		}

	private static int getMaxReads(LinkedList<String> preads) {
		// TODO Auto-generated method stub
		int max = 0; int id = 0;
		for(int i = 0; i < preads.size(); i++){
			String str = (String)preads.get(i);
			int tmp = Integer.valueOf(str.split("\\s+")[1]);
			if(tmp >= max){
				id = i; max = tmp;
			}
		}	
		return id;
	}
	
	private static void writeAnn(Alignment al, PrintWriter w) {
		
		char c[] = al.seq.toCharArray();
	
		int color = 6;
		int pair[] = getPair(al);
		
		int id = getMaxReads(al.preads);
		String tmp = null; int arr[] = null;
		if(al.preads.size()!=0){
			tmp = ((String)al.preads.get(id)).split("\\s+")[0];
			arr = new int[tmp.length()];
		}else{
			arr = new int[al.seq.length()];
		}
  
		if(al.preads.size()!=0){
		arr = addColor(w, arr, tmp, color );
		
		int a = tmp.split("[AGCTU]+")[0].length();
		int b = a + tmp.replace(".", "").length();
		String tmpstr = ((String)al.strc.get(0)).substring(a,b);
		
		
		int lt, st =0;
		if(tmpstr.replaceAll("[^(]", "").length() > tmpstr.replaceAll("[^)]", "").length()){
			lt = pair[a + tmpstr.indexOf('(')]; lt = lt+5;
			st = pair[a + tmpstr.lastIndexOf('(')]; st = st -5;
			
			
		}else{
			lt = pair[a + tmpstr.indexOf(')')];  lt = lt +5;
			st = pair[a + tmpstr.lastIndexOf(')')];  st = st - 5;

		}
		id = getMaxReads(al.preads, st, lt);
		if(id >=0) {
			tmp = (String)al.preads.get(id);
			arr = addColor(w, arr, tmp.split("\\s+")[0], color-1 );
		}					
		w.println("6");
		}else{
			w.println(1);
		}
		for(int i = 0; i < arr.length; i++){
			w.println((i+1) + "\t" +arr[i]+"\t"+c[i]);
		}
		w.flush();w.close();
	}
	
	private static int getMaxReads(LinkedList<String> preads, int st, int lt) {
		// TODO Auto-generated method stub
		int max = 0; int id = -1;
		for(int i = 0; i < preads.size(); i++){
			String str = (String)preads.get(i);
		
			String reads = str.split("\\s+")[0];
			int a = reads.split("[AGCTU]+")[0].length();
			int b = a + reads.replace(".", "").length();
			if(a>=st && b <=lt){
				int tmp = Integer.valueOf(str.split("\\s+")[1]);
				if(tmp >= max){
					id = i; max = tmp;
				}
			}
			
			
		}	
		return id;		
	}

	private static int[] addColor(PrintWriter w, int[] arr, String tmp, int color) {
		// TODO Auto-generated method stub
		char ts[] = tmp.toCharArray();	
		for(int j = 0; j < ts.length; j++){
			if(ts[j] == '.'){
				
			}else{	
				
			arr[j] = color; 
				
		
			}
		}
		return arr;
	}

	public static void main(String args[]){
                readin1(args[0], args[1], args[2]);
	}
}

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class RemoveLoci {

	
	private static BufferedReader reader;
	private static BufferedReader rgff;

	public static void filter1(String gff, String fn, String out, boolean flag){ 
		try{
			reader = new BufferedReader( new FileReader(fn));
			rgff = new BufferedReader( new FileReader(gff));
			PrintWriter w = new PrintWriter(out);
			String gf = rgff.readLine();
			String s = reader.readLine();
			while(s!=null && gf!=null){
				if(gf.startsWith("#")){s = reader.readLine(); continue;}
				String ts[]=s.split("\t"); String g[] = gf.split("\\s+");
				int st = Integer.valueOf(ts[3])+1; int ed = st + ts[4].length()-1; 
				int gst = Integer.valueOf(g[3]);	int ged = Integer.valueOf(g[4]);
				boolean tmp = ts[1].equals(g[6]) || flag;	
				if(ts[2].equals(g[0]) && tmp && Math.min(ged, ed) - Math.max(st, gst) >=0){
					s = reader.readLine();
				}else{
					int cmp = ts[2].compareTo(g[0]);
					if(cmp > 0){
						gf = rgff.readLine();
					}
					if(cmp==0){
						if(st > ged){
							gf = rgff.readLine();
						}else{
							w.println(s);
							s = reader.readLine();
						}
					}
					if(cmp <0) {w.println(s); s = reader.readLine(); }
					
				}
			}
			while(s!=null){
				w.println(s);
				s =  reader.readLine();	
			}
			w.flush(); w.close();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String args[]){
		filter1(args[0], args[1], args[2], Boolean.valueOf(args[3]));
	}
}


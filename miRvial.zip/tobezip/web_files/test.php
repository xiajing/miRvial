<?php
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
   $pageNum = $_GET['page'];
}
print $pageNum;

?>

<!DOCTYPE html>
<?
session_destroy();
ini_set("include_path", ".:/usr/share/pear:/usr/share/php:/export1/gbrowse/www/");
ini_set("display_errors", "1");
error_reporting(E_ALL);  
session_start();
#$GLOBAL_PREFIX="/export1/zhanglab/www/";
?>
<?
#print "<pre>";
#print_r($_SERVER);
#print "</pre>";
#exit;
if(isset($_SESSION['login'])){
  print "<div id=\"signout\"><a href=\"/~xiaj/pso/signout.php\">Sign Out</a></div>\n";
} elseif((strcmp($_SERVER['REQUEST_URI'],'/~xiaj/pso/index.php'))) {
  header("Location: /~xiaj/pso/index.php");
}
?>

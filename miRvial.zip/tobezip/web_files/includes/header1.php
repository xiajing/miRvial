<!DOCTYPE html>
<?
ini_set("include_path", ".:/usr/share/pear:/usr/share/php:/export1/zhanglab/www/");
session_start();
$GLOBAL_PREFIX="/export1/zhanglab/www/";
?>
<?
#print "<pre>";
#print_r($_SERVER);
#print "</pre>";
#exit;
if(isset($_SESSION['login'])){
//  print "<div id=\"signout\"><a href=\"/tmp/signout.php\">Sign Out</a></div>\n";
} elseif((strcmp($_SERVER['REQUEST_URI'],'/tmp/index.php'))) {
  header("Location: /tmp/index.php");
}
?>

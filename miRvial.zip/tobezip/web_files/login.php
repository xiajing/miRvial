<?
require_once("includes/header.php");
?>

<?
#if(strcmp('9358bac00c96653d31959f54a4061fb6', md5($_POST['passwd'])) == 0){
if(strcmp('mirna', $_POST['passwd']) == 0){
  $_SESSION['login'] = 1;
  print session_id().$_SESSION['login'];
  header("Location: index.php");
} else {
  unset($_SESSION['login']);
  print "nopass";
  header("Location: index.php?error_no=1");
}


<?php
$f = "str/1.png";
header('Content-disposition: attachment; filename=str/1.png');
header('Content-type: image');
readfile('str/1.png');
?>

<?
require_once("includes/header.php");
?>

<?
unset($_SESSION['login']);
header("Location: index.php");
?>

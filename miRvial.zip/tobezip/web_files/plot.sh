#!/bin/bash
source /export1/project/cassava2/xiaj/codes/mirtool/sourcelib

## Parse alignment
[ ! -d ss/ ] && mkdir ss
[ ! -d str/ ] && mkdir str

NUM=$(java mfoldPlot $1) ## parse alignment
echo $NUM

## Draw PS
for((i=1;i<=$NUM;i++))
do
b2ct <str/$i.str >str/$i.ct  ## change vienna format to ct format. b2ct comes from Vienna package
sir_graph -rot 90 -p -ss-count -af ss/$i str/$i.ct ## mfold generate figure`
done
#rm all.ps
for((i=1;i<=$NUM;i++))
do
#cat str/$i.ps >>all.ps
convert str/$i.ps str/$i.png
done
#sed -e 's/1.0 1.0 scale/0.7 0.7 scale/g' all.ps >all_1.ps
#ps2pdf all_1.ps

<?
require_once("includes/header.php");
?>
<h3><font color="#ff0000">Visualization of novel microRNAs in human skin. </font></h3>
<?
if( !isset($_SESSION['login']) ){
?>
<span style="font-size: 18px;">Please enter the password to continue</span>
<form method="POST" enctype="multipart/form-data" action="login.php" id="loginForm" name="loginForm">
  <input type="password" size="20" name="passwd" />
  <input type="submit" value="Enter" id="submit_form" />
</form>
<span style="font-size: 18px;">password: mirna</span>

<br>
<h3>Screenshot</h3>
<img src="mirna.gif">
<?
  exit;
}
?>

<html>
<head>
  <meta charset="utf-8">
  <title>Zhang Lab Pipeline</title>
  <script type="text/javascript" src="script1.js"></script>
  <link rel="stylesheet" type="text/css" href="1.css" >
  <!--<script src="modernizr.min.js"></script>-->
</head>

<body onload="ajaxFunction('1')";> 
<!--<body>
<select name="sel">
<option name="pso" value="pso">prosthesis</option>
<option name="mirtron" value="mir">miRtron</option>
</select>
<input type="button" value="choose" onClick="ajaxFunction('1'); return false;">
-->
<h3> Alignment</h3>
<div id="txtHint">
</div>

<!--image  -->
<h3> Images</h3>
<div id="image">
<img  width="500" height="350" >
</div>

<div id="fig">
<img  width="500" height="350" >
</div>

<!--<h3> List of selected items</h3>
<div id="selected">
</div>
<input type="button" onClick="ajaxDownload();" value="download">
-->


</body>
</html>


<?
require_once("includes/header1.php");

?>

<?php
#ini_set("memory_limit","128M");
require_once('alignclass.php');
require_once('page.php');


#$myFile = "/export1/gbrowse/www/tmp/pso/pso_071910-2.txt";
#if(isset($_GET['sel'])){
#	if($_GET['sel'] === 'mir' )) $myFile = "/export1/gbrowse/www/tmp/mir/topre_1.map.align";
#}else{
#}

# argument
#$myFile = "/export1/zhanglab/www/JOB_IO/mirtest/topre_1.map.align"; //alignment file
#$myFile = "/export1/zhanglab/www/JOB_IO/mirtest/topre.map.align_1";
$myFile = "./mir/pso_071910-2.txt";

#$lines = file($myFile); //define $lines in alignclass.php
$lines = array();
$count = 0;
$handle = fopen($myFile, 'r') or die ("file open handling");
if ($handle) {
    while (!feof($handle)) {
        $buffer = fgets($handle);
        $lines[$count] = $buffer;
        $count++;
    }
    fclose($handle);
}


$aligns = array();  // define $aligns in alignclass.php

$alignID = 1;
$count = count($lines);

# count how many blocks of alignments are in the file
for($i=0; $i<$count; $i++){
        if(strpos($lines[$i], ">") !== FALSE){
                $tmp = new Alignment($i);
                $i++;

                for(; $i <$count && (strpos($lines[$i], ">") === FALSE) ; $i++ ) {

                }
                $i--;
                $tmp->ed = $i;
                $aligns[$alignID] = $tmp;
                $alignID++;
        }
}

// numrows will be used for paging in the index.php
$numrows = $alignID-1;
echo "# of records: ".$numrows."</br>";


// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
   $pageNum = $_GET['page'];
}

//  numrows is in load.php
$offset = getOffset($pageNum, $numrows);

// $rowsPerPage in page.php
// function in index.php
printAll($offset+1, $offset+$rowsPerPage);

// print the navigation link
print '<div>';
print $first . $prev . $nav . $next . $last;
print '</div>';

?>

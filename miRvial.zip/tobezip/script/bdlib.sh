#!/bin/sh
geno=$2
java_r="/home/jingxia/codes/java/jdk1.8.0_45/bin/java"
bowtie -p 6 $geno -n 0 --norc  -f $1 >$1_norc
bowtie -p 6 $geno -n 0 --nofw  -f $1 >$1_nofw
$java_r -version
$java_r -cp ../src/ RevComNegRead $1_nofw $1_nofw_rc
cat $1_norc $1_nofw_rc | sort +4 -5 >tmp2
$java_r -cp ../src/  Unique tmp2 $1_lib

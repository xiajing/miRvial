/**
    miRvial - miRNAs via integrative analysis
    Copyright (C) 2015

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 **/

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.zip.GZIPInputStream;

public class Exgenomeseq {
	
	public static String currGenome = null;
	public static StringBuffer genome = null;
	public static int gsize = 30000000; // needs paramter
//	public static String dir = "C:/Users/think/datahouse/hg19/"; // needs paramter

	
	// given 
	public  static String seqExtract(String chro, int st, int ed, int strand, String dir, boolean isDir){
		
		if(currGenome != null && genome !=null && currGenome.equals(chro)  ){
		}else{
			if(!isDir){
				if(dir.endsWith("/"))dir = dir.substring(0, dir.length()-1);
			//	readChromosomeinOnefile(dir, chro);
				readChromosomeinOnefile1(dir, chro);
			}else{
				readChromosone(dir+chro );
			}
			currGenome = chro;
		}
		
		// note st is genomic loci while, sequence idx needs to be 1 less than st.
		if(st  <= 0) st =1; 								// protect overflow
		if (ed >= genome.length()) ed = genome.length();
	
		String ret =null;
		 ret = genome.substring(st-1, ed);
		if(strand == 1){
			return  ret;
		}else{
			return reversecomb(ret);
		}
	}
	
	private static BufferedReader reader1 = null;
	private static String currLine = new String();
	
	private static void readChromosomeinOnefile1(String chro, String contained) {
		boolean flag = false;
		try {
			if(reader1 == null){
				reader1 =new BufferedReader(new FileReader(chro));
			}else{
				
			}
			 genome = new StringBuffer(gsize);
			 while(currLine != null){
				 if(currLine.equals(">"+contained)){
					 flag = true;
					 currLine = reader1.readLine();
					 while(currLine!=null && !currLine.contains(">")){
						 genome.append(currLine);	
						 currLine = reader1.readLine();
					 }
					 break;
				 }else{
					 currLine  = reader1.readLine();
				 }
			 }
			 if(!flag){
				 reader1 = null; currLine = new String();
				 readChromosomeinOnefile1(chro, contained);
			 }
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}	
	
	private static void readChromosomeinOnefile(String chro, String contained) {
		// TODO Auto-generated method stub
		FileInputStream fin; 
		BufferedReader chroReader = null;
		 try {
			 if(chro.contains(".gz")){
				 fin = new FileInputStream(chro);
				 GZIPInputStream gzis = new GZIPInputStream(fin);
				 InputStreamReader xover = new InputStreamReader(gzis);
				 chroReader = new BufferedReader(xover);
			 }else{
				 if(chro.contains(".fa")){
					 chroReader = new BufferedReader(new FileReader(chro));
				 }else{
					 chroReader = new BufferedReader(new FileReader(chro+".fa"));

				 }
			 }			 			 
			 String s = chroReader.readLine(); 
			
			 genome = new StringBuffer(gsize);
			 while(s != null){
				 
				 if(s.contains(contained)){
					 s = chroReader.readLine();
					 while(s!=null && !s.contains(">")){
						 genome.append(s);	
						 s = chroReader.readLine();
					 }
					 break;
				 }else{
					 s = chroReader.readLine();
				 }
			 }
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	private static void readChromosone(String chro) {
		// TODO Auto-generated method stub
		
		 FileInputStream fin;
		 
		 BufferedReader chroReader = null;
		 try {
			 if(chro.contains(".gz")){
				 fin = new FileInputStream(chro);
				 GZIPInputStream gzis = new GZIPInputStream(fin);
				 InputStreamReader xover = new InputStreamReader(gzis);
				 chroReader = new BufferedReader(xover);
			 }else{
				 if(chro.contains(".fa")){
					 chroReader = new BufferedReader(new FileReader(chro));
				 }else{
					 chroReader = new BufferedReader(new FileReader(chro+".fa"));

				 }
			 }
	        File file = new File(chro);
			 			 
			 String s = chroReader.readLine(); 
			 s = chroReader.readLine();
			 genome = new StringBuffer((int)file.length());
			 while(s != null){
				 	genome.append(s);
					s = chroReader.readLine();
			 }
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		 
	}
	
	
    public static String reversecomb(String string) {
		// TODO Auto-generated method stub
		StringBuffer buf = new StringBuffer(string);
		char arr[] = buf.reverse().toString().toCharArray();
		for (int i = 0; i < arr.length; i++) {
			arr[i] = comp(arr[i]);
		}

		return String.valueOf(arr);
	}
    
    public static String compliment(String string) {
		// TODO Auto-generated method stub
	//	StringBuffer buf = new StringBuffer(string);
		char arr[] = string.toCharArray();
		for (int i = 0; i < arr.length; i++) {
			arr[i] = comp(arr[i]);
		}

		return String.valueOf(arr);
	}

	public static char comp(char c) {
		// TODO Auto-generated method stub
		switch (c) {
		case 'A': {
			return 'T';
		}
		case 'T': {
			return 'A';
		}
		case 'U': {
			return 'A';
		}
		case 'C': {
			return 'G';
		}
		case 'G': {
			return 'C';
		}
		case 'a': {
			return 't';
		}
		case 't': {
			return 'a';
		}
		case 'c': {
			return 'g';
		}
		case 'g': {
			return 'c';
		}
		case 'N': {
			return 'N';
		}

		default: {
			System.err.println("Unrecognized char " + c);
			return 'N';
//			System.exit(0);
		}
		}
	}

	public static void convertNegSeq(String locimap, String out) {
		// TODO Auto-generated method stub
		try {
			BufferedReader chroReader = new BufferedReader(new FileReader(locimap));
			PrintWriter w = new PrintWriter(out);
			int count = 0;
			String s = chroReader.readLine();
			while (s != null) {
				String sps[] = s.split("\t");
				if(sps[1].equals("-")) sps[4] = Exgenomeseq.reversecomb(sps[4]);
				
				for(int i = 0; i < sps.length; i++)
				w.print(sps[i]+"\t");
			
				w.println();
				
				s = chroReader.readLine();				
			}
			w.flush();w.close();
			//System.out.println(count); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	public static void main(String args[]) throws IOException{
		String str =seqExtract(args[0], Integer.valueOf(args[1]), Integer.valueOf(args[2]), Integer.valueOf(args[3]), 
				args[4], Boolean.valueOf(args[5]) );
		System.err.println(str);
	}	
}

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class RevComNegRead {
    public static String reversecomb(String string) {
		// TODO Auto-generated method stub
		StringBuffer buf = new StringBuffer(string);
		char arr[] = buf.reverse().toString().toCharArray();
		for (int i = 0; i < arr.length; i++) {
			arr[i] = comp(arr[i]);
		}

		return String.valueOf(arr);
	}

	public static char comp(char c) {
		// TODO Auto-generated method stub
		switch (c) {
		case 'A': {
			return 'T';
		}
		case 'T': {
			return 'A';
		}
		case 'U': {
			return 'A';
		}
		case 'C': {
			return 'G';
		}
		case 'G': {
			return 'C';
		}
		case 'a': {
			return 't';
		}
		case 't': {
			return 'a';
		}
		case 'c': {
			return 'g';
		}
		case 'g': {
			return 'c';
		}
		case 'N': {
			return 'N';
		}

		default: {
			System.err.println("Unrecognized char " + c);
			System.exit(0);
		}
		}
		return 0;
	}

	public static void convertNegSeq(String locimap, String out) {
		// TODO Auto-generated method stub
		try {
			BufferedReader chroReader = new BufferedReader(new FileReader(locimap));
			PrintWriter w = new PrintWriter(out);
			int count = 0;
			String s = chroReader.readLine();
			while (s != null) {
				String sps[] = s.split("\t");
				if(sps[1].equals("-")) sps[4] = reversecomb(sps[4]);
				
				for(int i = 0; i < sps.length; i++){
					w.print(sps[i]+"\t");
				}
			
				w.println();
				
				s = chroReader.readLine();				
			}
			w.flush();w.close();
			//System.out.println(count); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String args[]){
		System.out.println("RevNeg");		
		convertNegSeq(args[0], args[1]);
	}
}

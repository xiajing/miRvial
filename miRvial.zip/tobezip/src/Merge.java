import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.IOException;

public class Merge {

	
	// read two SORTED bowtie map, merge infos
    private static void doAccess(String fn1 ,String fn2, String out) {

        try {
        	BufferedReader rd1 = new BufferedReader(new FileReader(fn1));
        	BufferedReader rd2 = new BufferedReader(new FileReader(fn2));
        	PrintWriter w = new PrintWriter(out);
        	
        	String s1 = rd1.readLine();
        	String s2 = rd2.readLine();
        	
        	while(s1 != null ){
			String t1[] = s1.split("\t");
        		String t2[] = s2.split("\t");
        		int cmp = t1[4].compareTo(t2[4]);
        		if(cmp == 0){
        			for(int i =0 ; i < t1.length-1 ; i++){
        				w.print(t1[i]+"\t");
        			}
        			w.println(t2[t2.length-1]);
        			
        			s1 = rd1.readLine();
        		}
        		if(cmp < 0 ){ w.println(s1); s1 = rd1.readLine(); }
        		if(cmp > 0 ) s2 = rd2.readLine();
        	}
        	w.flush(); w.close();
          
        } catch (IOException e) {
            System.out.println("IOException:");
            e.printStackTrace();
        }
    }
 
    public static void main(String[] args) {
        doAccess(args[0], args[1], args[2]);
        
    }

}

